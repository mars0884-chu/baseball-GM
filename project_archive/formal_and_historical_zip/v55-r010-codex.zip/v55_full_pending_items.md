---
documentRole: full-pending-items
gameVersion: v55
documentRevision: 10
originalAuthor: Claude
lastModifiedBy: Codex
authoritative: false
packageId: v55-r010-codex
---
# 《決勝GM》v55 完整工作清單

## V55-GOV-001 — Codex-only 治理遷移

- STATUS：`DONE`
- PRIORITY：`CRITICAL`
- 現況：v03 治理文件已由 Mars 於 2026-08-09 正式核准。
- 目標：建立 Codex-only 權責、固定 10 角色、Development Log、Verification Report 與版本狀態制度。
- 設計依據：Mars 本輪決定、正式 `AGENTS.md`、`FUTURE_DELIVERY_STANDARD.md`。
- 允許修改範圍：治理文件與 r010 固定角色文件。
- 高風險區域：歷史作者來源、package lineage、角色替換映射。
- Acceptance Criteria：治理狀態正式生效；r010 使用新 10 角色；Claude 歷史來源不被抹除；Credits 格式仍由 Mars 決定。
- Migration：文件治理遷移，不改 Save。
- Test Requirement：角色、manifest、SHA 與乾淨封裝驗證。
- Dependency：無。

## V55-MIG-001 — Migration chain 完整稽核

- STATUS：`DONE`
- PRIORITY：`CRITICAL`
- 現況：r009 hydrate 只直接到 V54，`ensureV55()` 沒有正式呼叫者；既有 Regression 直接呼叫 V55 而漏測。
- 目標：確認真實讀檔路徑、影響範圍與 lazy ensure，再以最小方式接通 V55。
- 設計依據：Save／Migration 鐵則、Root Cause First、Mars 本輪指示。
- 允許修改範圍：`06-ui-roster.js` 共用 hydrate 與 `test_regression.js`。
- 高風險區域：Save backward compatibility、共享 RNG、三條正式讀檔入口。
- Acceptance Criteria：根因與影響有書面證據；開頁、手動槽位、JSON import 均共用 hydrate；V55 欄位補齊；重複執行不覆寫有效值。
- Migration：V54 後呼叫既有 idempotent `ensureV55()`；不新增 schema、不刪 key、不改型別。
- Test Requirement：真實 hydrate、真實 import、手動槽位、開頁委派、idempotent、Regression、兩個 Smoke、Save validation。
- Dependency：V55-GOV-001。

## V55-ART-001 — 球員詳情頁半身像（肩膀／領口）

- STATUS：`READY`
- PRIORITY：`HIGH`
- 現況：現有球員詳情視覺尚未完成肩膀與領口正式構圖。
- 目標：建立符合既有角色比例與球衣接口的正式半身像顯示。
- 設計依據：北極星視覺方向、`v55_art_interface_spec.md`、正式人物像素鎖定規則。
- 允許修改範圍：核准 1254px 母版衍生的獨立局部層、正式尺寸輸出、Theme／Portrait 顯示層。
- 高風險區域：臉、耳、帽、隊徽、膚色、姿勢與球衣保護區。
- Acceptance Criteria：先完成一款 1254px 候選；遮罩外 visible RGB／Alpha 0 差異；確認表含原母版、候選、200% 耳／臉線與 256px；Mars 核准後才輸出 256／128／64。
- Migration：無；美術不得影響機制。
- Test Requirement：遮罩驗證、Alpha、固定底色 visible RGB、production manifest、Theme render。
- Dependency：r010 `MARS_ACCEPTED` 與 Mars 指示開始。

## V55-ART-002 — 九款非禿頭髮型主稿

- STATUS：`READY`
- PRIORITY：`HIGH`
- 現況：方向已確認，但尚未逐款完成像素鎖定正式稿。
- 目標：依序完成九款非禿頭髮型；每次只製作與核准一款。
- 設計依據：Mars 已確認方向、1254px 正式母版與局部生成限制。
- 允許修改範圍：帽後／頭後層與帽簷下前髮層；不得重新生成整張人物。
- 高風險區域：帽子、隊徽、左右耳、耳線、臉線、眉眼嘴、膚色、身體與球衣。
- Acceptance Criteria：每款由核准母版獨立開始；遮罩外 0 差異；Mars 核准後才縮圖與進 production；失敗候選標記 rejected-do-not-use。
- Migration：無。
- Test Requirement：逐像素 Alpha 與 visible RGB、確認表、正式尺寸與 art manifest。
- Dependency：V55-ART-001 的半身像流程確認；Mars 每款批准閘門。

## V55-LONG-001 — 文化 UI 深化

- STATUS：`MARS_DECISION`
- PRIORITY：`MEDIUM`
- 現況：程式已有文化資料骨架，正式玩家出口尚未深化。
- 目標：待 Mars 決定版次、資訊密度與玩家互動邊界。
- 設計依據：資訊不對稱、人的意志、時間的複利。
- 允許修改範圍：待決定。
- 高風險區域：新增第二套 state、無出口屬性、Save 膨脹。
- Acceptance Criteria：待 Mars 定義。
- Migration：可能需要新版本 ensure；未決定前不得實作。
- Test Requirement：待方案決定。
- Dependency：Mars 排程。

## V55-LONG-002 — 城市動態演化

- STATUS：`MARS_DECISION`
- PRIORITY：`MEDIUM`
- 現況：已有 `cityState` 骨架與季末入口。
- 目標：待 Mars 決定城市演化速度、可見出口與對財務／球迷的界線。
- 設計依據：時間的複利、美術不入機制。
- 允許修改範圍：待決定。
- 高風險區域：百年資料膨脹、AI 特權、平衡與 Save。
- Acceptance Criteria：待 Mars 定義。
- Migration：可能需要新版本 ensure；未決定前不得實作。
- Test Requirement：待方案決定。
- Dependency：Mars 排程。

## V55-LONG-003 — 百年史冊 UI

- STATUS：`MARS_DECISION`
- PRIORITY：`MEDIUM`
- 現況：已有部分歷史資料骨架，完整百年史冊呈現未落地。
- 目標：待 Mars 決定史冊層級、查詢方式與留存粒度。
- 設計依據：時間的複利、資料正確、出口原則。
- 允許修改範圍：待決定。
- 高風險區域：長期資料量、真算來源、手機可用性。
- Acceptance Criteria：待 Mars 定義。
- Migration：可能需要新版本 ensure；未決定前不得實作。
- Test Requirement：待方案決定。
- Dependency：Mars 排程。

## V56-SCOPE-001 — v56 正式範圍

- STATUS：`MARS_DECISION`
- PRIORITY：`HIGH`
- 現況：r010 尚為 `TECHNICAL_RC`。
- 目標：Mars 接受 r010 後，決定 v56-r001 的必做範圍與第一個可施工項目。
- 設計依據：Mars 本輪「r010 接受前不得升 v56」。
- 允許修改範圍：只做範圍定義，不先改程式。
- 高風險區域：過早正式升版、未定義 Migration、版本階段越界。
- Acceptance Criteria：Mars 明確接受 r010；選定 v56 scope；建立具完整最小規格的 READY task。
- Migration：依選定功能決定。
- Test Requirement：依選定功能決定。
- Dependency：r010 `MARS_ACCEPTED`。
