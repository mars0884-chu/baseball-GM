---
documentRole: codex-development-log
gameVersion: v55
documentRevision: 12
originalAuthor: Codex
lastModifiedBy: Codex
authoritative: false
packageId: v55-r012-codex
---
# 《決勝GM》v55 Codex Development Log

## 歷史完成項目

- `V55-GOV-001`：r010 完成 Codex-only 治理遷移。
- `V55-MIG-001`：r010 完成 Migration chain 稽核、最小修正與真實入口 Regression。
- r010 驗證：Regression 1618/0、兩個 15 年 Smoke、Save 與封裝均通過；Mars 於 2026-08-09 實機確認可執行並接受。

## V55-UI-001 — 球員肖像槽位尺寸適配

- 日期：2026-08-09
- 目的：修正 Mars 回報的國際球員市場頭像像是超出圖框。
- 設計依據：Mars 真機回報、Root Cause First、美術不入機制。
- Root Cause：`themePlayerPhoto()` 內層 `.v49portrait` 固定 64px；市場卡外層 `.v48photo` 為 48px 且 `overflow:hidden`，造成內層被裁切。
- 影響範圍：市場／選秀／自由球員 48px 卡；交易 32px 與詳情 80px 也共用同一固定 64px 內層，具相同尺寸不一致風險。
- 修改檔案：`style.css`、`test_regression.js`。
- 實作內容：照片槽位直接子層 `.v49portrait` 寬高統一為 100%，各畫面仍由外框決定最終尺寸。
- Migration：無；不改 S、Save、Theme schema、素材、RNG 或平衡。
- 新增測試：3 項 Regression；實際瀏覽器量測前五張 48px 卡的內層均完整落在邊框內容區。
- 驗證結果：Regression 1621/0；兩個 Smoke PASS；Save validation PASS；Desktop render PASS。
- 風險：本輪瀏覽器驗證介面固定 1280×720，390×844 獨立 viewport 為 NOT RUN；r010 的 390×844 結果不可冒充本輪。
- 後續：交 Mars 真機確認 r011；接受後進 V55-ART-001。

## V55-PKG-011 — TECHNICAL_RC 封裝

- 日期：2026-08-09
- 目的：產出可直接開啟、可保存的完整 r011 ZIP。
- 設計依據：Codex-only 固定 10 角色、20 模組、完整 Art ZIP、SHA 與 lineage 規則。
- 修改檔案：單檔 HTML、模組 ZIP、Project Summary、Pending、Art Interface、Development Log、Verification Report、manifest、SHA。
- 實作內容：重新內嵌既有 285 份官方素材；Art ZIP 位元不變；正式母包為 r010。
- Migration：無新增 Save schema。
- 驗證結果：以 `v55_verification_report.md` 為準。
- 後續：r011 只交付 `TECHNICAL_RC`；等待 Mars 接受，不自動升 v56。


## Task：V55-R012-GATE-C-PRODUCTION（2026-09-03）

- 目的：依 Mars 明確 Gate C 授權，把 M4、M5、明亮 UI baseline 與已完成 QA scope 從 staging 提升為 production r012。
- Root cause／現況：r011 只有 bald compatibility hair 與 PNG team logos；staging 已完成四 family hair topology 與 20 個 SVG team mappings，但尚未改正式包。
- 修改：`00-theme.js` 新增 deterministic slot-5 hair rig dispatch；theme pack 新增 style03 v12/style04 v11/style05 Method C v05 paths；Art ZIP 新增實際載入 SVG／PNG；production CSS 採明亮 token adapter；`themeTeamLogo()` 保留為獨立 logo 入口。
- 保護：既有 capMark、skin、face、uniform、Save、RNG 與 simulation 位元未被替換；拒絕的 style05 候選未進包。
- 測試：Regression 1624/0、一般 15 年 Smoke PASS、Pure GM 15 年 Smoke PASS、Save／JSON PASS；既有 UI desktop/mobile fit proof PASS，本輪 localhost 視覺重取 NOT RUN；clean extraction／SHA PASS。
- Gate：Mars 2026-09-03 明確「Gate C 通過，允許進 production」，因此本版可標記 `MARS_ACCEPTED`／`active`。
