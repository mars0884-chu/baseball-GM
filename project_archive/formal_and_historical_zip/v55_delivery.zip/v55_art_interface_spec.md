---
documentRole: art-interface-spec
gameVersion: v55
documentRevision: 12
originalAuthor: Claude
lastModifiedBy: Codex
authoritative: false
packageId: v55-r012-codex
---
# v55 production 美術介面規格（r012）

## 圖層與路徑

- 正式 Art ZIP 僅放遊戲實際載入的 `production_assets/` 64／128／256px 與 SVG、單一最新 `theme_pack/`、兩份 `docs/`。
- `teams.T0...T19.logo` 是獨立 SVG mapping，僅供戰績／比分／名單／交易列；不可替代 `capMark`。
- `capMark` 仍沿用 r011 20 個完整帽子 PNG，檔案與 SHA 不變。
- 頭像 runtime 使用 256px layer 並以 CSS 縮放；Art ZIP 同時保留已核准 raster 的 64／128／256 尺寸。

## Portrait contract

`style03_v12`: `hairRear → skinHead/ears → hairSideByHeadFamily → hairFront → faceFeatures → cap`

`style04_v11`: `skinHead/ears → hairOverlayByHeadFamily → faceFeatures → cap`

`style05_method_c_v05`: `hairRearSvg → hairSideSvg → skinHead → visibleTempleLockSvg → faceFeatures → cap`

四個 head family 為 `standard`、`longFace`、`pointedChin`、`bigEars`。所有 layer 以同一 256px 座標系對位；髮型可輕微覆蓋耳朵／眉毛，但不得溢出帽體、破壞臉線、下巴或帽徽。

## 保護區與 fallback

skin、雙耳、耳線、臉線、眉、眼、嘴、膚色、帽子、帽徽、球衣、Save 與模擬資料皆不可由髮型 layer 改寫。若 hair rig 缺件，renderer 回退既有 bald compatibility asset，遊戲仍可運行。
