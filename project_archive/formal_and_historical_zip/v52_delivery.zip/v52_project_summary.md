---

## v52-r003 Codex 國旗品質修正（2026-07-27）

- 本包 packageId 為 `v52-r003-codex`，直接母包為 `v52-r002-codex`，`formalVersionUpgrade: false`。
- r002 的國旗細節未達 Mars 要求，已撤回且未提升為 current；r003 以可追溯來源重新製作。
- 20 個真實國家旗幟採固定 `flag-icons 7.3.2` 4×3 SVG，MIT 授權與來源檔一併保存在美術包；正式 SVG 對來源 20/20 位元相同。
- 20 個虛構國家旗幟為明確標示的原創向量設計，不冒充真實國旗；逐面設計說明見 `docs/v52_flag_sources_and_designs_v02.json`。
- 40 面旗均提供 SVG、128、64、32 px，共 160 個檔案；素材驗證 1070/1070，Theme pack v05 驗證 140/140。
- 程式、模組 ZIP、Claude handoff 與 art interface spec 均未修改。T5–T19 仍未獲 Mars 視覺核准。
- Mars 已確認「v51 已存檔，可以提升 current」。本輪完整驗收通過後，current 可由 v51 提升至本包。
- 未來 Claude 若增加正式遊戲版次，Codex 美術與固定 10 角色必須同步增加版次；只有同一正式版往返才增加 packageRevision。
- 可見整合現況：`themeNationFlag()` 目前沒有 UI 呼叫，國旗為 0 個可見出口；組合肖像只在即時比賽有 1 個 64px 出口。因此「素材已完成」不等於「一般遊玩畫面已實裝」，下一輪程式整合由 Claude 負責。
- Mars 最終決定：官方美術必須由 Claude 內建且預設啟用；玩家不得手動匯入主題包，正式版不應保留一般使用者匯入入口，重設也不得退回 emoji／空白美術。

documentRole: project-summary
gameVersion: v52
documentRevision: 3
originalAuthor: Claude
lastModifiedBy: Codex
authoritative: true
packageId: v52-r003-codex
---

# 決勝GM 專案脈絡還原包（v52-r002／通用肖像零件＋40 國旗）

> 產出日期：2026-07-27
>
> **本檔是《決勝GM》專案唯一的權威脈絡還原摘要，由 Mars／Claude／Codex 三方共用**
> （AGENTS.md 第三章、FUTURE_DELIVERY_STANDARD.md 第 3 節）。
> 只有本檔可含完整 copy-ready fenced restoration block；
> 其他固定角色文件只能引用本檔，任何出入一律以本檔為準。
>
> 使用方式：開新對話時貼入下方 fenced code block 全部內容，並附上本交付 ZIP 作為背景基礎

---

```markdown
# 《決勝GM》v52 脈絡還原摘要

> **本摘要是專案唯一權威脈絡還原文件，Claude 與 Codex 共用。**
> 交付包內其他文件皆為輔助，與本摘要出入時以本摘要為準。

## 1. 專案名稱與版本

- 專案名稱：**決勝GM: FRONT OFFICE BASEBALL**
- 當前版本：**v52**（逐打席比賽引擎重寫＋A5 捕手專項完整體系＋A1 自身簡化 W1~W5 全部補完；
  兩個數值靶心命中）
- 回歸測試基準：**1299 項全綠**（v51 的 1232 → v52 新增 67 項）
- 版本沿革：v24 → … → v49 → v491 → v50（美術接口定案）→ v51（A1 進階數據引擎）
  → **v52（逐打席引擎＋A5 捕手專項）**
- 下一版範圍：**尚未指定**，由 Mars 拍板。收官大項剩 A2/A3/A4 三項
  （Claude 建議順序：A2 農場多層級 → A4 承諾系統 → A3 文化傳承；Mars 已同意「其他順序依照建議」，
  但各自的版本歸屬尚未拍板）。
- package lineage：`packageId: v52-r002-codex`（revision 2，createdBy Codex，
  basedOn/supersedes `v52-r001-claude`，`formalVersionUpgrade: false` 同版美術修訂）
- 交付制度：AGENTS.md＋FUTURE_DELIVERY_STANDARD.md（固定 10 外層角色，唯一權威摘要即本檔）

### ⚠ 乙案（徹底修正）註記 — Mars 2026-07-27 拍板

v52 的兩個數值修正採 **Mars 指定的乙案：徹底修正**，不是表層調參。其後果已知並經 Mars 同意：

- **允許改動打擊事件機率**：比賽核心由「常態分布抽比分」改為「逐打席事件累積」，
  打擊事件機率成為引擎第一性參數（`V52_CFG`）。
- **接受回歸基線重建**：回歸斷言由 v51 的 1232 項重建為 **1299 項**；
  勝負分布、獎項門檻、AI 交易估值基準、牛棚出賽分布**全部隨新引擎重新校準**。
- **共用 RNG 序列必然改變**：這是乙案的預期後果，不是 bug。
  v51 以前「回歸一項未掉即證明 RNG 零變動」的判準**不再適用於 v52 這一次升版**；
  v52 之後的版本仍須恢復「共用 RNG 序列不得因美術／UI／統計衍生改動而變化」的紀律。

## 2. 遊戲架構

### 定位

瀏覽器端職棒 GM 經營模擬遊戲。玩家扮演球隊總經理，只管經營／策略／管理／行銷／建設，
與 AI 球隊競爭。靈感來源為電影《Moneyball》。

**北極星憲法三支柱**：
- **資訊不對稱**：球探評估有誤差，真值不可見（L1/L2/L3 三層）
- **人的意志**：教練、球員、球迷、老闆都有自己的意志與記憶，不是可任意擺佈的數值
- **時間複利**：決策後果跨年累積，百年時間尺度

**權力邊界**：GM 不排打線（純 GM 模式下投打守全交教練），透過「需求單」與教練溝通。

### 技術架構

- 六模組 vanilla JS（無框架、無建置流程）
- mobile-first PWA，IndexedDB 存檔
- 交付形式：整合單檔 HTML（離線自足）＋ 20 檔模組版
- 測試：Node.js vm 沙盒回歸測試 ＋ 雙 15 年 smoke test ＋ 整合單檔自驗

### 模組職責

| 檔案 | 職責 |
|------|------|
| `00-theme.js` | 主題／美術接口層（圖示語意化、槽位、肖像合成、主題包導入驗證） |
| `01-data-engine.js` | 資料引擎（球員生成、屬性、球探評估、球隊建構、完整資料卡、榮譽殿堂、v51 進階數據引擎、**v52 捕手六項專項＋新統計欄位**） |
| `02-finance.js` | 財務（預算、票房、設施、行銷、球迷三維度、冠軍獎勵、**分析室等級**） |
| `03-simulation.js` | 模擬（比賽、賽程、事件系統、里程碑、隊長、國際賽、v51 衍生接線、**v52 逐打席比賽引擎＋V52_CFG 校準常數**） |
| `04-state-core.js` | 狀態核心（存檔讀寫、新遊戲、選隊、升級鏈） |
| `05-ui-dashboard.js` | UI 主控台（儀表板、選隊、財務、談判、國際賽、主題設定） |
| `06-ui-roster.js` | UI 名單（球員名單、詳情、交易、選秀、殿堂、教練、hydrate、**v51 進階數據區塊**） |

### 核心迴圈

    球季開打 → 每日模擬 → 事件/傷病/教練需求打斷
      → GM 決策（交易/簽約/設施/行銷/回應需求）
      → 球季結束 → KPI 考核 → 休賽季（選秀/自由市場/續約/教練異動）
      → 下一年

## 3. 遊戲開發的核心進度

12 階段路線圖已全部完成（Phase 0～11）。v38 之後僅以版本號推進。

### 版本沿革與回歸數

| 版本 | 重點 | 回歸數 |
|------|------|--------|
| v24~v28 | 核心玩法循環、信任/KPI/東山再起、經紀人辦公室 | 184 |
| v29~v31 | 球場設施經濟、折舊重建、傳承系統 | 328 |
| v32~v33 | 聯盟生態（AI 互交易）、生涯深化（委任/沉潛/應酬） | 417 |
| v34~v35 | 九項修正＋教學頁、第二輪穩定性、Safe Mode | 498 |
| v36 | ④⑤⑥ 修正、冠軍 5 項、Phase 10 事件系統 | 546 |
| v37 | Mars 十項＋Phase 11 PWA（代打代跑、隊長、KPI 談判） | 571 |
| v38 | 18 事件＋連鎖＋型態弧、國際賽逐場化（母國） | 611 |
| v39 | 潛力動態＋不可逆特質＋球探探價 | 658 |
| v40 | 談判球探報告徽章修正、UI 去雜亂、分頁 | 710 |
| v41 | GM/教練分權「教練核心委任制」 | 762 |
| v42 | 教練市場＋標籤後果＋Mars 四項需求 | 817 |
| v43 | 郵件中樞＋純 GM 全教練化＋傷兵遞補准駁 | 856 |
| v44 | 教練體諒溝通（需求單第四路徑） | 871 |
| v45 | 選秀順位交易＋球迷三維度＋求購市場 | 898 |
| v46 | 完整資訊卡＋確定性霧化＋重建漸進寬限 | 914 |
| v47 | 可導入美術層＋89 圖示語意化＋球探市場找人 | 948 |
| v48 | 六角雷達圖＋球員照片＋榮譽殿堂＋里程碑 | 1000 |
| v49 | 品牌更名決勝GM＋海嶺共和國＋組合肖像＋主題設定頁 | 1047 |
| v491 | TEAM_DEFS 固定 20 隊＋LEAGUE_BRAND＋選隊制＋GM 名稱 | 1069 |
| v50 | 美術接口定案＋肖像 context 端到端＋驗證完整化＋cityUniform 停用 | 1150 |
| v51 | A1 L3 進階數據引擎（統計衍生／AI 分析型／可見度分層） | 1232 |
| **v52** | **逐打席比賽引擎（甲案全重寫）＋A5 捕手六項專項＋A1 W1~W5 補完＋兩數值修正** | **1299** |

### 已完成的重大系統

| 系統 | 版本 | 說明 |
|------|------|------|
| 核心經營迴圈 | Phase 0-7 | 名單、育成、選秀、交易、教練、合約、自由市場、財務、行銷 |
| 40 國世界系統 | v25 | 20 真實＋20 架空，等級分層、名字池風格 |
| 春訓／國際賽 | v25/v38 | 春訓階段、國際賽事逐場化（母國） |
| 經紀人／GM 信任 | v27/v28 | 7 種經紀人性格、7 種 AI 球團性格、信任/KPI/解職/東山再起 |
| 球場設施經濟 | v30/v31 | 12 種設施、15 巨蛋槽位、逐場門票結算、折舊重建 |
| 聯盟生態 | v32 | AI 互相交易、交易流言、AI 主動提案、動態 KPI |
| 生涯深化 | v33 | 委任制工作邀約、聲望事件、沉潛年、經紀人辦公室 |
| 事件系統 | v36/v38 | 18 種事件、6 大類、連鎖事件 |
| GM/教練分權 | v41 | 6 種教練哲學、執行度折射、接管機制、需求單三鍵 |
| 教練市場 | v42 | 聯盟教練池、AI 搶人、意願系統、辭呈、續約談判 |
| 郵件中樞 | v43 | 全訊息收攏、現金交易、掛牌 AI 開條件、傷兵遞補准駁 |
| 教練體諒溝通 | v44 | 需求單第四路徑「體諒說明」＋可信度查證 |
| 選秀權交易／球迷三維度 | v45 | 順位交易、期待/耐心/認同、求購市場 |
| 完整資訊卡 | v46 | 全能力到處可見、確定性霧化、重建漸進寬限 |
| 可導入美術層 | v47 | 89 圖示語意化 218 處、14 槽位全接線、球探市場找人 |
| 視覺化 | v48 | 六角雷達圖、球員照片槽位、榮譽殿堂、里程碑報喜 |
| 品牌／肖像系統 | v49 | 決勝GM 更名、海嶺共和國、40 國 countryId、組合肖像 |
| 資料穩定化 | v491 | TEAM_DEFS 固定 20 隊、LEAGUE_BRAND、選隊制、GM 名稱輸入 |
| 美術接口定案 | v50 | PORTRAIT_SPEC、z-order、capMark、主客場球衣、主題包驗證 |
| L3 進階數據引擎 | v51 | 12 項 A1 欄位、18 項衍生指標、失分組成、分析型 AI 套利、可見度四層 |
| **逐打席比賽引擎** | **v52** | **九種打席結果、壘包狀態機、換投調度、延長賽、勝敗投救援判定** |
| **A5 捕手專項體系** | **v52** | **六項屬性全部接進引擎（框架／配球／阻殺／阻擋／傳球時間／投手調教）** |

## 4. 目前擁有的技術細節與功能

### 亂數紀律（極重要）

- **共用 RNG**：`Math.random()` 用於遊戲模擬，呼叫次數與次序**不得**因美術／UI／統計衍生改動而變化
- **隔離 PRNG**：敘事型隨機用 `v42rng()` / `v42Int()`；進階數據衍生用 `v51rng()` / `v51Int()` / `v51Hash01()`
- **確定性雜湊**：球探霧化用 `v46Fog()`、肖像用 `v49SeedHash()`、進階數據用 `v51Hash01()`

理由：回歸測試依賴可重現的模擬軌跡。v42/v43 都曾因此出現偶發漂移，已用隔離修法解決。
v51 A1 完全遵守此紀律 —— 回歸從 1150 一項未掉，直接證明共用 RNG 序列零變動。

**v52 的例外（乙案授權範圍內，僅此一次）**：逐打席引擎是比賽核心重寫，
比賽本身的隨機必須走共用 RNG，序列因此改變。這是 Mars 拍板乙案的預期後果，回歸基線已整批重建。
**但邊界不變**：v52 的 W2 wOBA 年度校準是**純函式快取**，不抽任何亂數；
W4 估值縮放與 W5 球探／選秀評分沿用 `v51Hash01()` 確定性雜湊。
回歸中「monkeypatch `Math.random` 計數必須為 0」的專項斷言在這些路徑上**仍然存在且仍然通過**。
v52 之後的版本恢復原紀律：非比賽核心的新功能一律不得動共用 RNG。

### 升級鏈

    ensureV25 → ensureV26 → … → ensureV49 → ensureV491 → ensureV50 → ensureV51 → ensureV52

新版一律接在尾端，透過惰性補值處理舊存檔，不做破壞性遷移。
新開局在 `newGame()` 中直接寫入 `S.v52 = { ver: 52 }`（欄位由 fresh*Stats 建齊，無須補值）。

`ensureV52()` / `v52EnsureStatFields()` 的補值規則：
舊存檔無 `OUTS` 時由既有 `IP` 反推；舊捕手以既有三項專項（framing／gameCalling／caughtStealing）
的平均值補上新三項（blocking／popTime／pitcherHandling），**不憑空變強**。

### 穩定 ID

| 類型 | ID 格式 | 定義位置 |
|------|---------|----------|
| 球隊 | T0～T19 | `TEAM_DEFS`（01-data-engine.js，Object.freeze） |
| 國家 | NAT_US / NAT_TW / NAT_HOME / NAT_F01～F19 | `NATIONS` |
| 球員外觀 | `appearanceSeed`（整數） | 生成時寫入，轉隊不變 |
| 美術目錄 | `brandKey`（如 jingan_guardians） | `TEAM_DEFS` |

### 20 隊固定品牌

| teamId | 隊名 | brandKey | 聯盟 | 分區 | 主色 | 輔色 |
|--------|------|----------|------|------|------|------|
| T0 | 靖安盾衛 | jingan_guardians | A | A1 | #1B3A6B | #C0C0C0 |
| T1 | 臨海獵鯊 | linhai_sharks | A | A1 | #005F73 | #0A9396 |
| T2 | 曲江水牛 | qujiang_buffalo | A | A1 | #6B4226 | #D4A373 |
| T3 | 永昌雄獅 | yongchang_lions | A | A1 | #B8860B | #1C1C1C |
| T4 | 明陽烈焰 | mingyang_blaze | A | A1 | #CC3311 | #FF8800 |
| T5 | 天啟鷹 | tianqi_eagles | A | A2 | #2E4057 | #D4AF37 |
| T6 | 龍城雲豹 | longcheng_leopards | A | A2 | #4A4A4A | #E8C547 |
| T7 | 星野銀狐 | xingye_foxes | A | A2 | #708090 | #C0C0C0 |
| T8 | 雲夢白鷺 | yunmeng_egrets | A | A2 | #F0F0F0 | #4682B4 |
| T9 | 東寧豹 | dongning_leopards | A | A2 | #1C1C1C | #D4A017 |
| T10 | 嘉禾金穗 | jiahe_harvest | B | B1 | #DAA520 | #228B22 |
| T11 | 瑞港海豚 | ruigang_dolphins | B | B1 | #0077B6 | #48CAE4 |
| T12 | 金川礦工 | jinchuan_miners | B | B1 | #5C4033 | #E8A838 |
| T13 | 玄武黑熊 | xuanwu_bears | B | B1 | #1C1C1C | #4B5320 |
| T14 | 朝陽赤鷹 | chaoyang_redhawks | B | B1 | #B22222 | #FFD700 |
| T15 | 鳳鳴紅雀 | fengming_redbirds | B | B2 | #C41E3A | #FFFACD |
| T16 | 銀灘破浪 | yintan_breakers | B | B2 | #006994 | #F5F5DC |
| T17 | 青川山羌 | qingchuan_serows | B | B2 | #2D6A4F | #B7E4C7 |
| T18 | 望海白鯨 | wanghai_whales | B | B2 | #E8E8E8 | #1E3A5F |
| T19 | 磐石鐵衛 | panshi_ironguard | B | B2 | #36454F | #A9A9A9 |

聯盟品牌：海嶺職業棒球聯盟（HPBL），A=海風聯盟、B=山岳聯盟。母國：海嶺共和國。

### v50 美術接口（已定案，不可推翻）

**PORTRAIT_SPEC**：母版 256×256，輸出 64px（名單卡片）/ 128px（詳情）。
三錨點：headTop(x0.50, y0.10) / faceCenter(x0.50, y0.38) / neckline(x0.50, y0.72)。

**z-order**：`skin → face → eyes → nose → uniform → hair → beard → cap`

**球衣規則**：
- `capMark` = 完整帽子圖層 256×256（帽身＋帽簷＋帽徽一體，不拆分）
- `homeUniform` = 白色系主場球衣；`awayUniform` = 球隊主色系客場球衣
- `cityUniform` **永久停用**（不在白名單、載入剝除、產生警告）
- 客場缺失回退 homeUniform；非比賽情境一律主場（`PORTRAIT_DEFAULT_AWAY = false`）

**肖像 context**：`compositePortrait(playerId, { player, teamId, isAway }, size)`
快取鍵：`playerId|teamId|size|H或A`

**主題包驗證**：`V50_TEAM_FIELDS` 白名單 9 欄、`V50_LAYER_NAMES` 8 個合法圖層、
`V50_LAYER_REQUIRED` 4 個必要圖層（skin/face/uniform/cap）、13 類警告。
警告不阻擋載入（讓 Codex 可漸進補齊素材）。

**持久化**：localStorage `v50_theme_pack` / `v50_theme_meta`；超過 5MB 自動回退 IndexedDB `v50_theme_db`

### v51 A1 進階數據引擎（本版新增）

**三項設計決策（Claude 依既有建議實作，Mars 可推翻）**：

| 編號 | 問題 | 採用方案 | 理由 |
|------|------|----------|------|
| ① | 產生方式 | **統計衍生** | 隔離 PRNG，共用 RNG 零變動，回歸 1150 全保。另案「逐打席引擎」需重寫模擬核心、回歸基準整批重建 |
| ② | AI 使用範圍 | **只有分析型（analytics）** | 保留 Moneyball 套利空間：其餘六種性格仍看表面數據，玩家可撿被低估球員 |
| ③ | 玩家可見度 | **綁定分析室（analysisRoom）等級** | 呼應憲法第一支柱資訊不對稱 |

**新增統計欄位（12 項）**：
- 打者七欄：`PA` 打席／`D` 二壘打／`T` 三壘打／`CS` 盜壘失敗／`GIDP` 雙殺打／`HBP` 觸身／`SF` 高飛犧牲
- 投手五欄：`HRA` 被全壘打／`R` 總失分／`HBPA` 投出觸身／`WP` 暴投／`BF` 面對打者數

**失分組成**：`R − ER = 非自責分`。讓 ERA 與實際失分脫鉤，成為守備品質的可觀測訊號。

**衍生指標（18 項，純函數無隨機）**：
- 打者：AVG／OBP／SLG／OPS／ISO／BABIP／BB%／K%／BB-K／盜壘成功率／wOBA 近似
- 投手：ERA／RA9／WHIP／K9／BB9／HR9／K-BB／**FIP**（常數 3.10）／投手 BABIP／非自責分佔比

**可見度四層（V51_TIERS）**：

| 層級 | 名稱 | 打者 | 投手 |
|------|------|------|------|
| Lv.0 | 基礎數據 | AVG／HR／RBI／SB | W-L／ERA／SO／SV |
| Lv.1 | 上壘與效率 | OBP／SLG／OPS | WHIP／K9／BB9 |
| Lv.2 | 數據拆解 | ISO／BB%／K%／BB-K／盜壘成功率／GIDP | HR9／K-BB／RA9 |
| Lv.3 | 真實能力指標 | BABIP／wOBA | FIP／投手 BABIP／非自責分佔比 |

自家球員保底 Lv.1。樣本不足（打者 <30 打數、投手 <10 局）時顯示提示而非誤導數據。

**關鍵函數**：
- `v51rng()` / `v51Int(lo,hi)` / `v51Hash01(seedStr,idx)` — 隔離 PRNG 與確定性雜湊
- `v51DeriveBatterGame(p, gAB, gH, gHR, gBB, gSO, gSB)` — 單場打者衍生
- `v51DerivePitcherGame(p, gIP, gER, gSO, gBB, gH)` — 單場投手衍生
- `v51SyncBatterPA(p)` — PA 恆等式同步（冪等；代打／代跑路徑亦呼叫）
- `v51BatterAdvanced(st)` / `v51PitcherAdvanced(st)` — 進階指標全集
- `v51VisibleTier(team, ownPlayer)` / `v51IsMetricVisible(kind, metric, tier)` — 可見度判定
- `v51AnalyticsValueAdj(p, team)` — 分析型 AI 估值修正（±12，接在 `personaTradeValue` 尾端）
- `v51AdvancedStatsHtml(p)` — 球員詳情進階數據區塊
- `ensureV51()` — 舊存檔惰性補齊

**v51 程式碼落點（原 claude_handoff 內容併入）**：
`01-data-engine.js`（統計欄位擴充／v51 區塊：PRNG、衍生、指標、可見度、AI、ensureV51；
`personaTradeValue` 尾端接 `v51AnalyticsValueAdj`）；
`03-simulation.js`（`attributeGameStats` 打者快照與衍生接線、先發與後援投手衍生、
`applyBenchCredits` 呼叫 `v51SyncBatterPA`）；
`04-state-core.js`（`newGame` 寫入 `S.v51`）；
`06-ui-roster.js`（`playerStatsSectionHtml` 尾端接進階數據區塊、hydrate 升級鏈接 `ensureV51`）；
`style.css`（`.v51adv-*` 純版面樣式）。

**絕對不要做的事（原 claude_handoff 內容併入）**：
不要把 v51 衍生改用共用 `Math.random()`（會炸 1232 項回歸）；不要把 PA 改回增量累加；
未經 Mars 拍板不調打擊率／防禦率相關參數；不要把 T5–T19 寫成已獲 Mars 視覺核准；
未來任何「加 AB 但不走 attributeGameStats」的新機制都必須呼叫 `v51SyncBatterPA`；
分析型 AI 估值是行為變更，若日後偶發漂移優先懷疑此處。

**200 天實測數值（合理性參考，非最終手感）**：
- 打者平均：AVG .234／OBP .291／SLG .386／OPS .677／ISO .153／BABIP .253／BB% 7.4%／K% 16.7%
- 投手平均：ERA 6.10／FIP 3.78／WHIP 1.39／K9 8.94／BB9 3.43／HR9 1.01／非自責佔比 9.8%
- 套利標的實際出現：例如 ERA 7.65 但 FIP 2.58 的投手（在非分析型球團眼中依然便宜）

### v52 逐打席比賽引擎＋A5 捕手專項（本版新增）

#### ① 逐打席引擎（A1-W1，Mars 指定甲案：完全重寫）

`simulateGame` 不再用 `randNormal` 抽比分，改由逐打席事件累積得出比分。

- **九種打席結果**：`BB` / `HBP` / `K` / `HR` / `3B` / `2B` / `1B` / `E` / `OUT`
- **壘包狀態機**：三壘包＋出局數；雙殺打、高飛犧牲打、盜壘與阻殺、暴投與捕逸
- **換投調度**：由局數／體力／疲勞／牛棚順位（中繼→布局→終結）決定，疲勞 >70 自動跳過
- **延長賽**最多 6 局；九局下後攻超前即再見結束；主隊領先不打九局下
- **勝敗投、救援成功、中繼成功**依實際登板情境判定
- 核心函式：`v52PlayGame` / `v52HalfInning` / `v52PA` / `v52SideInit` / `v52NeedChange` /
  `v52PickReliever` / `v52EnterPitcher` / `v52DecideDecisions` / `v52Commit` / `v52SyncIP`
- `simulateGame` / `attributeGameStats` 對外介面保留，呼叫端不需改寫

#### ② 兩個數值修正（靶心：打擊率 .250／防禦率 3.80）

v51 實測 BA .2385、ERA 6.270。根因診斷（Claude 實測一整季 20 隊 2520 隊·場）：

| 根因 | 內容 |
|---|---|
| 一（ERA 主因） | **投球局數帳本不完整**：一場只記先發約 5 局，後援僅在「贏球且分差 1~3」才登板各 1 局，每隊每場 IP 只有 5.61，分母短少約 3.4 局 |
| 二 | **自責分帳本同時灌水與漏水**：`qualityFactor` 平均值 1.3（平均投手被記 130% 比例分自責分）；同時全隊失分只有約 77% 被記為 ER，其餘既未入 ER 也未入非自責分 |
| 三 | **得分基準偏高**：基準寫 4.5，經評分差／守備修正／`Math.max(0)` 截斷／抗壓加分後實際達 5.112 |
| 四（BA） | 每隊每場 AB 36.33 偏高，且 `totalHits = round(runsScored×1.6 + randInt(-1,2))` 係數 1.6 偏低（實際 H/R 約 1.9~2.0） |

FIP 3.78 當時就已合理，正是因為 FIP 只吃 HR/BB/SO 不吃失分歸屬 —— 佐證問題全在失分帳本。

修法：①後援補足 `9 − 先發局數`；②先算全隊非自責分，team ER = 失分 − 非自責分，
再以 `局數 × qualityFactor` 為權重**按比例分配**（保證 ΣER 等於 team ER），
qualityFactor 從「總量放大」改為「相對份額」；③④校準得分基準、AB 與 H/R 係數。

| 指標 | v51 實測 | v52 實測 | 靶心 |
|---|---|---|---|
| 全聯盟打擊率 | .2385 | **.2500**（5 種子平均） | .250 |
| 全聯盟防禦率 | 6.270 | **3.86**（5 種子平均） | 3.80 |
| 每隊每場投球局數 | 5.61 | **9.00** | 9 |
| 每隊每場得分 | 5.112 | 4.15 | ~4.15 |
| 非自責分占比 | 帳本漏水約 23% | 7.0% | 7~9% |
| 三振率／四壞率 | — | 21.4% / 8.2% | 現實區間 |
| 每隊每場全壘打 | — | 1.00 | 現實區間 |

**ERA 落在 3.86 而非 3.80**：兩個數值互相牽制（得分基準同時決定 BA 與 ERA），
Claude 以打擊率精準命中 .250 為優先，ERA 收在 3.86。是否再往 3.80 逼近由 Mars 真機決定。

**校準常數集中在 `03-simulation.js` 的 `V52_CFG`**（14 組，全部可單點調整）：
`kBase 0.233` / `bbBase 0.0739` / `hbpBase 0.0095` / `hrRate 0.0224` / `babip 0.2724` /
`errRate 0.0145` / `gidpRate 0.105` / `sfRate 0.135` / `sbAttempt 0.075` / `sbBase 0.705` /
`wpRate 0.0088` / `homeAdv 0.036` / `runToMult 0.24` / `maxExtra 6`

#### ③ 牛棚調度模型修正（Mars 指正事項）

Mars 指出：中繼、後援一年 45~65 場出賽、40~70 局本來就正常，牛棚多人定位＋輪休＋疲勞體力值
就是為此設計；舊版後援登板不足是**一開始就沒設好的調度模型缺陷，不是修正的副作用**。

實測一整季（20 隊）：

| 定位 | 平均出賽 | 平均局數 | 防禦率 |
|---|---|---|---|
| 先發 | 25.0 | 130.2 | 3.46 |
| 中繼 | 65.1 | 64.6 | 4.30 |
| 布局 | 63.0 | 62.7 | 4.94 |
| 終結 | 40.7 | 39.9 | 4.45 |

#### ④ A5 捕手專項完整體系

v51 以前程式只有 gameCalling／framing／caughtStealing 三項，且**對比賽完全沒有作用**
（僅用於顯示／成長／估值）。v52 補上缺的三項，六項全部接進比賽引擎：

| 屬性 | 程式欄位 | 實際出口 |
|---|---|---|
| 接捕框架 Framing | `framing` | 對手 K% ↑、BB% ↓ |
| 配球引導 Game Calling | `gameCalling` | 全投手群失分修正（K/BB/HR/BABIP 全面） |
| 阻殺跑壘 | `caughtStealing` | 阻殺成功率 ↑ |
| **阻擋 Blocking**（新） | `blocking` | 暴投／捕逸機率 ↓ |
| **傳球時間 Pop Time**（新） | `popTime` | 對手盜壘成功率 ↓ |
| **投手調教 Pitcher Handling**（新） | `pitcherHandling` | 投手臨場穩定度加成；25 歲以下投手成長加速 |

關鍵函式：`v52Cat(catcher, key)`（缺捕手取中庸值 50）／`v52CatcherOf(team, players)`／
`v52CatcherScore(c)`（六維合計）／`v52HandlingGrowthBonus(team, player)`（成長出口）。
同步擴充：捕手訓練室說明、年度成長、球探報告、完整資訊卡、名單頁屬性列、交易估值、特訓畫面。

#### ⑤ A1 自身簡化 W1~W5 全部補完

| 編號 | v51 簡化內容 | v52 補完方式 |
|---|---|---|
| W1 | 進階數據為統計衍生，非逐打席產生 | **逐打席引擎重寫**（見①），BABIP／FIP 反映真實逐打席結果 |
| W2 | wOBA 為線性權重近似，無逐年聯盟環境校準 | `v52LeagueBatting()` / `v52WobaScale()`：以本季全聯盟實測縮放，使聯盟平均 wOBA 對齊聯盟平均 OBP；每 7 個比賽日重算一次（快取），純函式不消耗共用亂數 |
| W3 | 非自責分為固定低頻近似，未掛鉤守備 | 非自責分改由**守備失誤**直接產生（失誤率隨球隊守備評分變動），失誤後該半局後續得分不計入自責分 |
| W4 | 分析型 AI 估值修正上限固定 ±12 | `v52AnalyticsCap()`（Lv.0 ±6 → Lv.5 ±21）＋ `v52SampleWeight()` 樣本線性淡出；捕手另加 A5 專項套利加分 |
| W5 | 進階數據未進球探報告與選秀評估 | `v52ScoutAdvancedHtml()` 讓完整資訊卡帶本季進階數據（沿用 v51 分析室可見度分層）；`v52DraftScore()` 讓分析型球團選秀改看選球、控球與年輕度 |

#### ⑥ 新增統計欄位

- 打者：`R`（得分）／`PB`（捕逸）／`CSC`（阻殺成功）
- 投手：`OUTS`（出局數）——**`IP` 一律由 `OUTS` 精確換算**（保留一位小數，20 出局＝6.7 局）
- 清單常數：`V52_BAT_FIELDS`（3）／`V52_PIT_FIELDS`（1）／`CATCHER_FIELDS`（6）
- `sw.js` 快取鍵改為 `baseballgm-v52`

#### ⑦ v52 程式碼落點

`01-data-engine.js`（捕手六項屬性生成與成長、新統計欄位、`v52DraftScore`、`v52ScoutAdvancedHtml`、
`ensureV52`）；`03-simulation.js`（**逐打席引擎全部十個函式、`V52_CFG`、W2 wOBA 校準、
W3 非自責分、`attributeGameStats` 改由引擎入帳**）；`02-finance.js`（`v52AnalyticsCap` 接分析室等級）；
`04-state-core.js`（`newGame` 寫入 `S.v52`、hydrate 升級鏈接 `ensureV52`）；
`06-ui-roster.js`（捕手六項顯示、進階數據區塊、特訓與訓練室）；`sw.js`（快取鍵）。

#### ⑧ 順帶修掉的既有 bug

AI 球隊若因教練市場異動（v42 起）留下空缺，`processCoachContracts()` 會因 `if (!c) return;`
直接跳過，使該隊**永久缺人**。舊版只是被亂數序列掩蓋，並非設計意圖。已改為 AI 隊空缺一律補實。

#### ⑨ 絕對不要做的事（v52 版）

- 不要把 `IP` 改回獨立累加：`IP` 必須永遠由 `OUTS` 換算，否則帳本會再次漂移
- 不要把非自責分改回固定低頻：它現在是守備失誤的下游結果（W3）
- 不要在 W2/W4/W5 路徑引入 `Math.random()`：這些必須維持純函式或確定性雜湊
- 不要單獨調 `V52_CFG` 的得分相關常數而不重跑全季量測：BA 與 ERA 互相牽制
- 不要把 T5–T19 寫成已獲 Mars 視覺核准
- 未經 Mars 拍板不再調整打擊率／防禦率相關參數

## 5. 已解決的問題

| 問題 | 解法 | 版本 |
|------|------|------|
| 手機完全打不開 | 用 Edge 等真實瀏覽器開啟（iOS 檔案 App 的 Quick Look 不執行 JS） | v35.2 |
| 第二輪教練無法更換 | `takeJobOffer` 清除舊隊待處理佇列 | v35 |
| 球探替換閃退 | 四個渲染路徑加入空缺守衛 | v35 |
| 開機白畫面 | init IIFE render 包 try/catch ＋ Safe Mode 回復畫面 | v35.1 |
| 第二年選秀被吞掉 | `beginFirstSeason` 清 `S.draft` ＋ 重入守衛修正 | v39.1 |
| 球探報告徽章空白 | draftgrades 容器修復 | v40 |
| 榮譽殿堂進去出不來 | `renderHallOfFame()` 補 `wireRosterNav()` | v49 |
| 回歸測試偶發漂移 | 隔離 PRNG ＋ 固定種子覆寫 | v42/v43 |
| 主客場球衣沒有呼叫端 | 明確 ctx `{player, teamId, isAway}` ＋ 比賽情境接通 | v50 |
| 主題包驗證太淺 | 完整白名單 ＋ URI 格式 ＋ layerOrder 四項檢查 | v50 |
| cityUniform 規格不一致 | 停用欄位 ＋ 載入剝除 ＋ 相容警告 | v50 |
| **代打球員 PA=0** | **PA 改為恆等式重算（`v51SyncBatterPA`），代打／代跑路徑亦呼叫** | **v51** |
| 進階數據可能污染共用 RNG | 全走 `v51Hash01` 確定性雜湊；回歸新增專項斷言 monkeypatch `Math.random` 計數必須為 0 | v51 |
| **投球局數帳本短少四成（ERA 6.27 主因）** | **後援補足 `9 − 先發局數`，全隊每場投球局數補齊到 9.00** | **v52** |
| **自責分同時灌水與漏水** | **team ER = 失分 − 非自責分；再以 `局數 × qualityFactor` 按比例分配，保證 ΣER 等於 team ER** | **v52** |
| **打擊率 .2385 偏低** | **校準每隊每場 AB 至約 34、提高 H/R 係數至約 2.0，實測 .2500** | **v52** |
| **非自責分與守備無關** | **改由守備失誤直接產生（A1-W3），失誤後該半局後續得分不計自責分** | **v52** |
| **捕手三項專項對比賽完全無作用** | **補上 blocking／popTime／pitcherHandling，六項全部接進逐打席引擎** | **v52** |
| **AI 球隊教練空缺永久補不上** | **`processCoachContracts()` 的 `if (!c) return;` 改為一律補實** | **v52** |

## 6. 程式開發需求與條件

### 不得違反的硬性約束

1. **共用 RNG 序列**不得因美術／UI／統計衍生改動而變化
   （**v52 例外**：Mars 拍板乙案授權比賽核心重寫，序列改變為預期後果，回歸基線已整批重建；
   此例外僅限 v52 這一次升版，v52 之後恢復原紀律）
2. **存檔相容性**透過 `ensureVXX()` 升級鏈惰性補值，不做破壞性遷移
3. **升級鏈順序**新版一律接在尾端
4. **模組邊界**：00-theme.js 只放主題／美術接口，不放遊戲規則
5. **20 檔模組版**：模組 ZIP 必須恰為 20 檔
6. **整合單檔離線自足**：不得引入外部 CDN 或字型連結
7. **未導入主題包時位元等價**：美術接口未導入資產時必須回退到 emoji／CSS 外觀
8. **警告不阻擋載入**
9. **全部繁體中文**：程式註解、UI 文字、對話一律繁體中文
10. **美術映射用穩定 ID**（teamId/countryId），不用可能變動的顯示名稱
11. **文件不得把未完成的美術工作寫成已完成**
12. **所有檔名一律純 ASCII，無任何例外**；ZIP 內所有 entry 路徑亦須 ASCII，不設 UTF-8 旗標
13. **交付制度依 AGENTS.md 與 FUTURE_DELIVERY_STANDARD.md**（Mars 2026-07-26 拍板的正式標準，
    取代先前所有「跨版母包不可刪減」與「D 案替換制」敘述）。要點：
    固定 10 個外層角色（不得增刪）；同版往返以 packageRevision +1 更新固定角色而非堆檔；
    正式升版時 10 個角色全部換新版檔名、revision 從 1 起、formalVersionUpgrade: true；
    舊版完整 ZIP 即歷史與回滾包，不嵌入新版；新舊由 packageId／SHA-256 判定，不看檔名與時間。
14. **唯一權威脈絡摘要**：`v52_project_summary.md` 是 Claude 與 Codex 共用的唯一權威摘要，
    也是唯一可含完整 copy-ready fenced restoration block 的文件；其他固定角色文件只能引用本檔。
15. **雙向 handoff 所有權**：`v52_claude_to_codex_handoff.md` 只有 Claude 可寫；
    `v52_codex_to_claude_handoff.md` 只有 Codex 可寫，Claude 位元不變保留、不得代寫。
    handoff 只記交接與差異，不得成為第二份摘要。
    **v52 的 `v52_codex_to_claude_handoff.md` 是由母包 `v51_codex_to_claude_handoff.md`
    位元不變承接（僅改檔名），內容仍為 Codex 在 v51 輪的原文，Claude 未改一個位元。**

### 交付前驗收（四項全過才可交付）

| 測試 | 執行指令 | v52 結果 |
|------|---------|----------|
| 完整回歸 | `node test_regression.js` | **1299 通過 / 0 失敗**（exit 0） |
| 一般模式 15 年 smoke | `node smoke_multiyear.js` | **全部通過**（exit 0） |
| 純 GM 模式 15 年 smoke | `node smoke_puregm.js` | **全部通過**（exit 0） |
| 整合單檔自驗 | 抽出 script 在 vm 沙盒執行 | **21 通過 / 0 失敗** |

單檔自驗實測數值：打擊率 .2493／防禦率 3.873／每隊每場投球局數 9.00／非自責分 6.8%。
（自驗腳本在 v52 封裝輪重建為 21 項，涵蓋 v52 引擎函式、A5 六項、升級鏈與全季四項數值；
v51 的 32 項腳本針對 v51 A1 撰寫，非同一組斷言，數字不可直接相比。）

Windows PowerShell `Expand-Archive` 的實機驗證由 Codex 在 `v51-r003-codex` 輪完成
（外層 10 檔、美術 375 檔皆乾淨解壓）；**v52 的美術 ZIP 為位元不變承接，該結論繼續有效**，
但 v52 外層 ZIP 本身尚未由 Codex 在 Windows 實機驗證。
回歸與雙 smoke 必須在解壓後的模組目錄執行。

有失敗必須明列，不得寫成全數通過。

### 20 檔模組版固定清單

00-theme.js／01-data-engine.js／02-finance.js／03-simulation.js／04-state-core.js／
05-ui-dashboard.js／06-ui-roster.js／baseball_gm_century_empire_design_v1_2.md／design_doc.md／
icon-180.png／icon-192.png／icon-512.png／index.html／manifest.webmanifest／
smoke_multiyear.js／smoke_puregm.js／style.css／sw.js／test_regression.js／theme_pack_example.json

### 摘要與交接摘要標準（10 項必含）

①專案名稱 ②遊戲架構 ③核心開發進度 ④技術細節與功能 ⑤已解決的問題
⑥程式開發需求與條件 ⑦三方工作內容 ⑧待辦與未完成 ⑨記憶錨點 ⑩檔案說明清單。
摘要正文必須用單一 Markdown fenced code block 包裝。

## 7. Mars／Claude／Codex 三方工作內容

| 角色 | 職責 | 不做的事 |
|------|------|----------|
| **Mars** | 設計方向、需求定義、真機測試、最終拍板；參數手感驗證 | 不寫程式碼 |
| **Claude** | 唯一工程師：程式碼、測試、回歸、交付文件、美術接口定義 | 不自行決定設計；不自行決定開發範圍 |
| **Codex** | 美術製作：隊徽、肖像零件、球衣、帽子、圖示、國旗、Theme pack | 不動遊戲規則、模擬、數值、RNG、存檔語意 |

### 重要協作規則

- **美術與遊戲功能必須同時並行完成**，不分開輪流（Mars 明確指正過兩次）
- 需要 Mars 決定的內容直接在對話中提問，**不放在文件裡**
- 未獲回覆的問題要**再問一次**，不自行猜測
- **但已經拍板過的範圍不可再問**（Mars 2026-07-26 指正：v51 範圍早就定為 A1，不該重問「要做什麼」）
- Mars 先看根因分析再核准修法，拍板後才動工
- Mars 要求「先開發完再提供」，不接受分批零碎交付
- Claude 交回 Codex 的 ZIP 必須與收到的同構（Codex 給什麼就回什麼，僅追加不刪減）

## 8. 待辦事項與未完成內容

### 收官大項（原 5 項，A1 已完成，剩 4 項）

| 編號 | 項目 | 憲法章節 | 狀態 |
|------|------|----------|------|
| ~~A1~~ | ~~L3 進階數據引擎~~ | ~~§4.4-4.6~~ | **✅ v51 完成（W1~W5 於 v52 全部補完）** |
| A2 | 農場多層級（目前只有一軍/二軍） | §5.2 | 未動工（Claude 建議下一個做） |
| A3 | 球隊文化/城市記憶/二代傳承 | §11.2-11.4 | 未動工（建議最後做） |
| A4 | 承諾系統（簽約承諾與兌現） | — | 未動工（建議 A2 之後） |
| ~~A5~~ | ~~捕手專項完整體系~~ | — | **✅ v52 完成（六項全接進引擎）** |

收官大項由 5 項降為 **3 項**。Claude 建議順序 A2 → A4 → A3，Mars 已同意「其他順序依照建議」，
但**各自的版本歸屬尚未拍板**，下一版範圍仍須 Mars 指定。

### v51 自身簡化事項（5 項，v52 全部補完）

| 編號 | 狀態 |
|------|------|
| ~~W1~~ | ✅ v52 逐打席引擎重寫 |
| ~~W2~~ | ✅ v52 wOBA 逐年聯盟環境校準 |
| ~~W3~~ | ✅ v52 非自責分掛鉤守備失誤 |
| ~~W4~~ | ✅ v52 估值修正動態縮放＋樣本淡出 |
| ~~W5~~ | ✅ v52 進階數據進球探報告與選秀評估 |

（W5 的「教練需求單措辭」部分未做 —— 見下方 v52 自身簡化 V3。）

### v52 自身簡化事項（新增 4 項）

| 編號 | 說明 |
|------|------|
| V1 | 逐打席引擎為**打席層級**，非逐球（無好壞球數、無配球序列、無球種）；打席結果一次抽出 |
| V2 | 守備只以球隊守備評分影響失誤率與 BABIP，無逐守位守備範圍／臂力判定，無守備位置別失誤 |
| V3 | 進階數據已進球探報告與選秀評估，但**未進教練需求單措辭**（W5 的剩餘部分） |
| V4 | 換投調度為規則式（局數／體力／疲勞／順位），無情境化調度（左右對戰、危機續投判斷、開局投手） |

### 待 Mars 真機把關的 v52 數值

| 項目 | v51 | v52 實測 | 靶心 | 備註 |
|------|-----|----------|------|------|
| 打者平均打擊率 | .234 | **.250** | .250 | ✅ 命中 |
| 投手平均防禦率 | 6.10 | **3.86** | 3.80 | 差 0.06；兩數值互相牽制，是否再逼近由 Mars 決定 |

**v51 的兩項待調參數已由 v52 解決，不再列為待調。**
新的待調對象是 `V52_CFG` 的 14 組校準常數（見下）。

### 版本簡化事項（原 28 項＋v51 五項已補完 −5＋v52 新增 4 項＝32 項）

- **v35**：S1 跨隊殘留佇列丟棄處理／S2 超額外籍降二軍無新聞／S3 新手教學靜態文本
- **v37**：代打代跑代守為機率微調非逐打席／隊長加成只走抗壓通道／守位缺口 3 條啟發式／KPI 談判只能降成績類／SW 只快取 App Shell
- **v38**：極端潛力受 20-99 硬切／型態弧型不顯示／國際賽只母國逐場其餘擲幣／國際賽不造成疲勞傷病／代表隊無教練設施隊長加成／事件連鎖只有單層／國家羈絆不衰減
- **v39**：potBase 位移不重套軟上限／跨季存活以本季賽程近似／摺疊開合不入存檔
- **v42**：意願僅一軍總教練／教練市場新面孔只在 picker 補充／代理教練季末懸缺近似／青年育成季末單屬性+1
- **v43**：遞補輪值折射僅玩家隊／現金線性當量近似／郵件中樞無過濾搜尋封存
- **v44**：體諒為本季一次性撤需求／耐心磨損固定-2
- **v45**：選秀順位交易無保護條件／選秀權估值無樂透加權／AI 未主動夾帶選秀權／認同未含承諾球風掛鉤
- **v46**：完整卡疲勞在球探模式顯示「—」
- **v47**：Z1 球探出勤固定 14 天／Z1 只掃自由+國際市場
- ~~**v51**：W1~W5~~ —— **已於 v52 全部補完，自清單移除**
- **v52**：V1 打席層級非逐球／V2 守備只到球隊評分層級／V3 進階數據未進教練需求單措辭／
  V4 換投調度為規則式無情境化判斷

### 待真機調整的參數（原 18 組＋v51 新增 2 項）

原 18 組（v33 應酬成功率 70%／引薦折扣 95%／委任信任偏移 ±5／競爭稅門檻 +15%／沉潛聲望 +5；
v37 隊長抗壓 +4／代打代跑代守觸發率 22%/16%/22%；v38 型態振幅 ±18／事件連鎖延遲 25-55 天／
國家羈絆上限 10；v43 現金當量 120 萬/價值點／AI 開價頻率 35%日／報價時效 10 天；
v44 沒經費門檻 3000 萬／重建年輕線均齡 26.5／識破信任懲罰 -6；v45 過期減罰 -3／
球迷三維度四出口幅度；v46 重建漸進壓力曲線 0.20→1.0）維持原值，**目前一律不改任何數值**。

~~v51 新增待調：打者平均打擊率 .234、投手平均防禦率 6.10~~ —— **已由 v52 解決，移除。**

**v52 新增待調：`V52_CFG` 共 14 組校準常數**
（kBase／bbBase／hbpBase／hrRate／babip／errRate／gidpRate／sfRate／sbAttempt／sbBase／
wpRate／homeAdv／runToMult／maxExtra）。這些是逐打席引擎的第一性參數，
已用 5 種子平均校準到靶心，**Mars 未指示前不再調整**。
調任何一個都必須重跑全季量測，因為 BA 與 ERA 互相牽制。

### Backlog 功能（10 項，全未排期）

B1 多層事件連鎖／B2 39 國逐場國際賽／B3 國際賽疲勞傷病／B4 代表隊配教練設施隊長／
B5 選秀權保護條件／B6 AI 主動用選秀權交易／B7 羈絆衰減機制／B8 型態弧型可視化／
B9 郵件中樞進階（過濾搜尋封存）／B10 PWA 上架託管

### 純 GM 模式教練 AI 手感（R1）

自 v41 起持續標記「待 Mars 真機把關」，目前未收到具體回饋。

### 美術層進度（Codex 端）

**已完成**：20 隊隊徽（512/128/64/32px）／20 隊帽徽參考／20 隊品牌概念板／品牌色票／
PORTRAIT_SPEC／z-order／正式品牌 Theme pack v01／**全 20 隊 capMark＋homeUniform＋awayUniform
（60 張 256px 主素材＋120 張縮圖，Theme pack v03）**

**核准狀態**：T0–T4 已獲 Mars 樣板核准；**T5–T19 為候選素材，尚待 Mars 視覺核准（不得寫成已核准）**

**待製作**：肖像零件（skin/face/eyes/nose/hair/beard）／語意圖示（97 個 emoji→SVG/PNG）／
槽位資產（26 個）／國旗（40 國）／六大畫面背景、按鍵、卡片、雷達圖與事件素材

### 統計摘要

| 類別 | 數量 |
|------|------|
| 收官大項 | 3（原 5，A1 於 v51、A5 於 v52 完成） |
| 版本簡化事項 | 32（原 33，v51 W1~W5 補完 −5，v52 新增 V1~V4 +4） |
| 待調參數 | 32 組（原 20，v51 兩項解決 −2，v52 `V52_CFG` +14） |
| Backlog 功能 | 10 |
| 美術待製作項 | 3 大項（通用肖像零件與 40 國旗於 r002 完成） |
| **合計未完成** | **約 80 項**（`V52_CFG` 14 組列入待調，另完成 2 個美術大項） |

## 9. 記憶錨點

### 已定案不可推翻

- 20 隊固定品牌（TEAM_DEFS，Object.freeze）— Mars 拍板
- 聯盟品牌 LEAGUE_BRAND（海嶺職業棒球聯盟/HPBL/海風聯盟/山岳聯盟）— Mars 拍板
- 母國海嶺共和國、40 國靜態 countryId
- PORTRAIT_SPEC 三錨點、z-order 八層順序
- capMark = 完整帽子（方案 A，不拆分）
- cityUniform 永久停用
- 選隊制：userTeamId 不限 T0，玩家只輸入 GM 名稱
- v51 A1 三項設計決策：統計衍生／只有分析型 AI 使用／綁定分析室等級解鎖
  （其中「統計衍生」已於 v52 由逐打席引擎取代；「只有分析型 AI 使用」與
  「綁定分析室等級解鎖」仍然有效）
- **v52 逐打席引擎採甲案（完全重寫）** — Mars 2026-07-27 拍板
- **v52 兩數值修正採乙案（徹底修正）**：允許改動打擊事件機率、接受回歸基線重建 — Mars 拍板
- **數值靶心：打擊率 .250／防禦率 3.80**（介於美、日職棒之間）— Mars 拍板
- **牛棚出賽量的認定**：中繼／後援一年 45~65 場、40~70 局屬正常，
  牛棚多人定位＋輪休＋疲勞體力值就是為此設計 — Mars 指正，不得再視為異常
- **A5 捕手六項全部必須對比賽有實際作用**，不得只做顯示 — Mars 認定 v51 現況為缺陷

### 重要教訓

- **v42/v43 回歸偶發漂移**：起因是敘事型隨機動到共用 RNG。修法＝隔離 PRNG。
  此後所有隨機都必須先判斷屬於共用還是隔離。**v51 從一開始就走隔離，回歸一項未掉。**
- **手機打不開三個版本才解決**：真因是 iOS 檔案 App 的 Quick Look 不執行 JS，用 Edge 開啟即可。
- **Claude 曾誤讀 Mars 需求範圍（2026-07-26 上午）**：Mars 說「未完成項目清單也必須要有進度一並完成」
  意為實際推進未完成項目，Claude 誤讀為僅附上清單並標記進度。
- **Claude 曾重問已拍板的範圍（2026-07-26 下午）**：v51 範圍＝A1 進階數據引擎，
  上一次對話就已決定並寫進摘要，Claude 卻再問「這次要做什麼」，Mars 明確指正。
  **教訓：先查摘要與未完成清單，範圍已定就直接動工；只有真正未拍板的設計選項才發問。**
- **Codex Theme pack 只是美術素材整合**，不等於遊戲未完成項目有進度；兩者必須同時推進。
- **「回歸全綠＝沒動共用 RNG」這個判準有適用範圍（2026-07-27）**：它只在功能不碰比賽核心時成立。
  v52 逐打席引擎是比賽核心重寫，回歸基線必須整批重建，此時全綠證明的是新基線自洽，
  不是 RNG 序列未變。判準本身沒錯，錯在套用範圍。
- **診斷要看帳本不要看參數（2026-07-27）**：ERA 6.27 的真因不是「投手太爛」而是
  投球局數只記了 5.61 局、自責分同時灌水又漏水。FIP 3.78 合理正是關鍵線索——
  它不吃失分歸屬。**先找哪個統計量沒被記帳，再談調參。**
- **封裝輪必須拿到母包才能動工（2026-07-27）**：v52 封裝需要位元不變承接美術 ZIP、
  Codex handoff 與美術規格書，並需要母包內 9 檔的個別 SHA 才能寫 `carriedForwardFrom`。
  沒有母包時**不得以記憶、舊解壓目錄或同名檔替代**，必須停下來要求上傳。

### Mars 溝通規則

- 回覆全程繁體中文（無對應翻譯時才允許英文）
- 需要 Mars 決定的內容直接在對話中提問，不放在文件裡
- 未獲回覆的問題要再問一次，不自行猜測；**但已拍板的範圍不可再問**
- 上下文記憶容量達 50%/70%/80%/90% 時主動提醒，90% 尤其要提醒
- 遊戲開發與 Codex 美術要求**必須一起完成**，不可只做其中一項

## 10. 檔案說明清單

### 外層交付 ZIP（固定 10 個角色，AGENTS.md 第四章）

| # | 檔案（角色） | 作者權 | 說明 |
|---|---|---|---|
| 1 | `52_baseball_gm.html` | Claude | 整合單檔，離線可執行，手機用 Edge 開啟；**v52 新版** |
| 2 | `52_baseball_gm_modular.zip` | Claude | 20 檔模組版，開發與測試用；**v52 新版** |
| 3 | `v52_art_assets.zip` | Codex | 美術素材完整包：**561 個檔案＋1 個零位元組目錄佔位 entry＝562 個 ZIP entries**；母包既有 375 檔位元不變，新增通用肖像零件、40 國旗、Theme pack v04 與驗證資料，反斜線 entry 為 0 |
| 4 | `v52_project_summary.md` | 本輪封裝者（Claude） | **本檔：唯一權威脈絡還原摘要** |
| 5 | `v52_full_pending_items.md` | 本輪封裝者（Claude） | 全部未完成項目＋五類缺口 |
| 6 | `v52_art_interface_spec.md` | Claude 維護 | 美術接口規格；**v52 未修改，由母包位元不變承接** |
| 7 | `v52_claude_to_codex_handoff.md` | **只有 Claude 可寫** | Claude→Codex 交接與差異；本輪由 Claude 更新 |
| 8 | `v52_codex_to_claude_handoff.md` | **只有 Codex 可寫** | Codex→Claude 交接與差異；**內容為 Codex 在 v51 輪的原文，由母包位元不變承接，Claude 未改一個位元** |
| 9 | `v52_delivery_manifest.json` | 本輪封裝者（Claude） | package lineage＋逐角色來源與變更狀態 |
| 10 | `SHA256SUMS.txt` | 本輪封裝者（Claude） | 雜湊其餘 9 檔，不含自身，最後重建 |

### package lineage（目前狀態與新制 bootstrap）

目前完整包是 `v52-r002-codex`，直接母包為 `v52-r001-claude`：

- legacy bootstrap parent：`v51-legacy-bootstrap-claude-20260726`（12 檔版，無正式 packageId）
- v51 新制首包：`v51-r001-claude`（revision 1）→ `v51-r002-codex`（revision 2）
  → `v51-r003-codex`（revision 3，v51 最終）
- v52 正式升版首包：`v52-r001-claude`／revision 1／`formalVersionUpgrade: true`，
  basedOn/supersedes `v51-r003-codex`。
- **本包：`packageId: v52-r002-codex`／`packageRevision: 2`／`createdBy: Codex`／
  `basedOnPackageId: v52-r001-claude`／`supersedesPackageId: v52-r001-claude`／
  `formalVersionUpgrade: false`**

正式升版規則：10 個角色全部換成 v52 檔名、revision 從 1 起算、`formalVersionUpgrade: true`、
lineage 指向上一正式版的最後 packageId。母包 `v51_delivery.zip`
（SHA-256 `29BF46A56D226FFB5E960416D1EC896906FD72240794422B8C16A49FD683E669`，54,093,017 bytes）
本身即歷史與回滾包，不嵌入本包，請自行保存。

### v51-r003-codex → v52-r001-claude 逐角色承接映射

| 母包檔案 | 本包檔案 | changeStatus | 說明 |
|---|---|---|---|
| `51_baseball_gm.html` | `52_baseball_gm.html` | **modified** | v52 程式（逐打席引擎＋A5＋W1~W5）；檔名隨正式升版更換 |
| `51_baseball_gm_modular.zip` | `52_baseball_gm_modular.zip` | **modified** | 同上，恰 20 檔 |
| `v51_art_assets.zip` | `v52_art_assets.zip` | **unchanged** | **位元不變承接**，只改檔名；`carriedForwardFrom.contentSha256` 等於母包同檔 SHA |
| `v51_project_summary.md` | `v52_project_summary.md` | **modified** | 本檔：Claude 依 v52 內容更新 |
| `v51_full_pending_items.md` | `v52_full_pending_items.md` | **modified** | Claude 依 v52 內容更新＋本輪五類缺口 |
| `v51_art_interface_spec.md` | `v52_art_interface_spec.md` | **unchanged** | **位元不變承接**；v52 未新增任何需要美術素材的接口 |
| `v51_claude_to_codex_handoff.md` | `v52_claude_to_codex_handoff.md` | **modified** | Claude 重寫本輪交接內容 |
| `v51_codex_to_claude_handoff.md` | `v52_codex_to_claude_handoff.md` | **unchanged** | **位元不變承接**；只有 Codex 可寫，Claude 未改一個位元 |
| `v51_delivery_manifest.json` | `v52_delivery_manifest.json` | **replaced** | 新 lineage（v52-r001-claude） |
| `SHA256SUMS.txt` | `SHA256SUMS.txt` | **replaced** | 最後重建，雜湊其餘 9 檔，不含自身 |

**三個 unchanged 角色的驗證方式**：把本包檔案與母包同名（v51 前綴）檔案做 SHA-256 比對，
必須完全相同。三者的 SHA 見 `v52_delivery_manifest.json` 的 `files[].carriedForwardFrom`。

### v52-r001-claude → v52-r002-codex 直接承接

- `52_baseball_gm.html`、`52_baseball_gm_modular.zip`、`v52_art_interface_spec.md`、
  `v52_claude_to_codex_handoff.md`：位元不變承接。
- `v52_art_assets.zip`：modified，保留母包 375/375 原檔並新增通用肖像零件與 40 國旗。
- `v52_project_summary.md`、`v52_full_pending_items.md`、`v52_codex_to_claude_handoff.md`：
  由 Codex 更新。
- manifest 與 SHA 清單：replaced，最後重建。

### 美術素材 ZIP 內部結構（375 個檔案、376 個 ZIP entries）

`v51-r003-codex` 已將所有內部路徑正規化為 `/`；反斜線 entry 為 0。
**v52 為位元不變承接（只改檔名為 `v52_art_assets.zip`），Claude 未重新打包，
因此不可能重新引入反斜線。** 封裝後已再次實測：376 entries／375 檔案／1 目錄／
反斜線 0／非 ASCII 0，與母包完全一致。
Windows `Expand-Archive` 與跨平台 ZIP 工具皆可形成預期目錄樹（Codex 在 v51 輪已實機驗證）。

- `production_assets/teams/T0～T19/` — logo_512/128/64/32.png ＋ cap_mark_reference_256.png
  ＋ **capMark_256/128/64_v01.png ＋ homeUniform_256/128/64_v01.png ＋ awayUniform_256/128/64_v01.png**
- `concept_boards/` — 20 隊品牌概念板
- `theme_pack/` — 8 個 JSON，最新為 `v50_official_brand_theme_v03_all_20_portrait_layers.json`
- `docs/` — manifest／validation／readme／產製方法／歷史審查文件（19 檔）
- `previews/` — 聯絡表、contact sheet、64px 測試、透明度 QA（26 檔）
- `tools/` — 建置與驗證腳本（18 檔，.py / .mjs）
- `ART_PROJECT_MEMORY.md`／`FUTURE_DELIVERY_STANDARD.md`

### 20 檔模組版內容

七個 JS 模組（00-theme／01-data-engine／02-finance／03-simulation／04-state-core／
05-ui-dashboard／06-ui-roster）＋ index.html ＋ style.css ＋ sw.js ＋ manifest.webmanifest
＋ 三個 icon PNG ＋ 三個測試腳本 ＋ theme_pack_example.json ＋ 兩份設計文件

---

## 開新對話使用方式

1. 開新對話
2. 貼入本 fenced code block 完整內容
3. **附上 v52 交付 ZIP** 作為背景基礎（缺少 ZIP 時 AI 無法驗證程式碼現況，只能依摘要推論）
4. 說明本次要做什麼

**若下一輪是封裝輪或需要承接既有角色，必須同時附上母包 ZIP** ——
位元不變承接與 `carriedForwardFrom` 的 SHA 只能從母包實際算出，不能靠記憶或舊解壓目錄。

## Codex v52-r002 美術階段（2026-07-27）

- 母包：`v52-r001-claude`，原始 ZIP SHA-256
  `195C8EDA881359D945BFC033EBE1BAFF76A698003A78896619B1AB21F83EB15E`
- 程式與模組 ZIP 位元不變，Claude handoff 位元不變；Codex 未修改遊戲規則、RNG 或存檔語意。
- 新增通用肖像零件 32 張 256×256 母版：
  skin 5、face 5、eyes 6、nose 6、hair 6、beard 4；另輸出 128/64，共 96 張 PNG。
- 新增 40 國旗：40 張 128px PNG＋40 張 SVG，映射既有 `NAT_*` countryId。
- Theme pack v04 同時提供 paths 與 embedded 版本；保留既有 20 隊品牌、帽子及主客場球衣。
- 新美術驗證：肖像／國旗 684/684，Theme pack 164/164，
  embedded 與 paths 版均 `validateThemePack valid=true / warnings=0`。
- v52-r001 原有 375 個美術檔逐檔 SHA 比對 375/375 位元不變。
- T5–T19 仍是候選素材，尚待 Mars 視覺核准；本輪未變更任何 T0–T19 隊伍素材。
- 尚待美術大項：97 個語意圖示、26 槽位資產、六大畫面背景／按鍵／卡片／雷達圖／事件素材。

**目前狀態**：`v52-r002-codex` 為 v52 最新完整美術修訂包。逐打席比賽引擎（甲案全重寫）、
A5 捕手六項專項、A1 自身簡化 W1~W5 全部完成；兩個數值靶心 BA .250 命中、ERA 3.86（靶心 3.80）。
回歸 1299/0、雙 smoke exit 0、單檔自驗 21/0 全綠。
收官大項剩 **A2 農場多層級／A4 承諾系統／A3 球隊文化傳承**（Claude 建議此順序，
Mars 已同意「其他順序依照建議」，版本歸屬未拍板）。下一版範圍等 Mars 指定。
Mars 尚未真機把關：v52 比賽節奏與數值手感、T5–T19 視覺核准、純 GM 教練 AI 手感（R1）。
```
