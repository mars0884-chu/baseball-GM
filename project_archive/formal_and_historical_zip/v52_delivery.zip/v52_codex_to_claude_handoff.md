---
documentRole: codex-to-claude-handoff
gameVersion: v52
documentRevision: 5
originalAuthor: Codex
lastModifiedBy: Codex
authoritative: false
packageId: v52-r003-codex
---

# 《決勝GM》v52 Codex → Claude handoff

交付日期：2026-07-27  
本輪負責：Codex（僅美術、文件與封裝；未修改程式）  
唯一權威摘要：`v52_project_summary.md`

## Lineage

- packageId：`v52-r003-codex`
- packageRevision：3
- createdBy：Codex
- basedOnPackageId / supersedesPackageId：`v52-r002-codex`
- formalVersionUpgrade：false
- r002 因 Mars 明確否決國旗細節品質而撤回，未提升為 current。

## 本輪國旗修正

Mars 要求以尊重國家的方式呈現清楚、可辨識、不可胡亂簡化的國旗細節。

- 20 個真實國家的正式 SVG 改採固定版本 `flag-icons 7.3.2` 的 4×3 SVG，並在包內保存 20 份來源 SVG 與 MIT `LICENSE`。
- 正式 SVG 與保存來源逐位元核對：20/20 相同。
- 每面旗輸出 SVG、128、64、32 px，共 160 個旗幟檔；PNG 均為 RGBA 且尺寸正確。
- 多明尼加、墨西哥、尼加拉瓜等帶國徽旗幟保留來源中的徽章細節；韓國保留太極與四卦；台灣保留青天白日細節；未再以隨意幾何圖代替真實旗幟。
- 20 個 `NAT_F01`–`NAT_F20` 是遊戲虛構國家，不冒充真實國旗；每面皆為原創向量設計，設計含義與色彩記錄於 `docs/v52_flag_sources_and_designs_v02.json`。
- Theme pack 更新為 v05 respectful flags，embedded 與 path 版本皆通過遊戲既有 `validateThemePack`。

## 驗證

- 素材驗證：1070/1070。
- Theme pack v05 驗證：140/140；embedded / paths 均 `valid=true`、0 warnings。
- 真實國旗正式 SVG 對固定授權來源：20/20 位元相同。
- 人像素材沿用 r002，未因國旗修正改動。
- T5–T19 仍未獲 Mars 視覺核准，不得寫成已核准。

## 分工與後續版次

- 程式仍由 Claude 負責；本包的 HTML、20-file modular ZIP、Claude handoff、art interface spec 均位元不變。
- Claude 若將遊戲正式升為 v53、v54 等，Codex 的美術交付與固定 10 角色檔名必須同步跟版，不得把美術鎖死在 v52。
- 同一正式版內往返才增加 packageRevision；新正式版依規則從 revision 1 開始。
- 捕手六項專項若需要新圖示槽位，請先由 Claude 更新下一版 `art_interface_spec`，Codex 再製作。

## 給 Claude

請只接收完整 `v52_delivery.zip`（packageId `v52-r003-codex`），不要使用已撤回的 r002。下一輪若升正式版，請以本包為 `basedOnPackageId` 的實際母包並同步更新全部 10 個外層角色。

## 必須處理的可見整合缺口

Mars 提供的實機截圖顯示目前一般遊玩畫面幾乎感受不到美術差異。Codex 對 v52 程式做只讀追蹤後確認：

- `themeNationFlag()` 只有定義與測試，UI 中沒有任何實際呼叫；因此 40 面國旗目前是 **0 個可見 UI 出口**。
- `compositePortrait()` 的 UI 呼叫只出現在 `06-ui-roster.js` 的即時比賽情境，為單一 64px 出口；新聞、一般名單與球員資料卡未展示。
- `themeTeamLogo()` 只在 dashboard 的一處使用。
- 官方 Theme pack 不會由正式 HTML 自動啟用；使用者必須進入「主題設定」手動匯入 JSON。

這些是 Claude 所屬的程式整合工作，不是再增加素材數量即可解決。下一個程式包至少應：

1. Mars 已決定：官方 Theme pack 必須由 Claude 內建並預設啟用。玩家不得被要求手動匯入；正式版也不應提供一般使用者「匯入主題包」的產品流程。
2. 在球員資料卡、名單／球探／交易與國家隊相關畫面加入可辨識的國旗出口。
3. 在球員資料卡與常用名單加入肖像出口，不只留在即時比賽。
4. 加入「目前套用的美術包版本」可見狀態，以及實機視覺 smoke 驗收截圖。
5. 保持 UI 接線不改變共用 RNG 序列。

Mars 第二張實機截圖另顯示「目前主題包：版本未標示、圖示 0 個、槽位 0 個」。請注意：r003 v05 embedded JSON 本身有 `version`，但沒有 `icons` 或 `slots`，因此一般 UI 不會大幅改變。下一版主題設定頁應另外顯示隊徽數、國旗數、肖像層數，避免以 icons / slots 誤導使用者判斷。

程式整合的完成標準不是單元測試或 `validateThemePack valid=true`；交付時必須附 dashboard、球員資料卡、國家隊／國籍、即時比賽至少四張實機截圖，證明素材在常用流程實際可見。

### Mars 2026-07-27 最終產品決定

- Claude 匯入／整合官方美術後，使用者開啟遊戲就必須直接處於已套用狀態。
- 不得要求玩家選 JSON，不得把「主題設定 → 匯入主題包」當正式使用步驟。
- 正式版應移除或隱藏一般使用者的匯入入口；若工程上仍需測試入口，只能存在於明確的開發模式。
- 「重設為預設」不得退回 emoji／空白美術；正式預設就是官方美術。
- r003 的 embedded JSON 是提供 Claude 整合的來源資產，不是玩家附件。
