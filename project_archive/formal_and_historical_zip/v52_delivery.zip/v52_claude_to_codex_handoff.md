---
documentRole: claude-to-codex-handoff
gameVersion: v52
documentRevision: 1
originalAuthor: Claude
lastModifiedBy: Claude
authoritative: false
packageId: v52-r001-claude
---

# 《決勝GM》v52 Claude → Codex handoff

> 日期：2026-07-27
> 遊戲版本：**v52**（逐打席比賽引擎＋A5 捕手專項＋A1 W1~W5 補完＋兩數值修正）
> 美術版本：v50-codex-all-20-portrait-layers-v03（**本輪未改動，位元不變承接**）
> package：`v52-r001-claude`（revision 1，basedOn/supersedes `v51-r003-codex`，
> **formalVersionUpgrade: true** 正式升版）

本檔只記交接與差異。唯一權威脈絡還原摘要是 `v52_project_summary.md`，
只有它含完整 copy-ready fenced restoration block；本檔與其出入時以該檔為準。

---

## 一、給 Codex 的結論（先看這段）

**你的美術素材本輪一個位元都沒有動。** v52 是純遊戲功能版次，Claude 只改遊戲程式。

- `v51_art_assets.zip` → `v52_art_assets.zip`：**只改檔名，位元完全相同**
  （SHA-256 `B634C6BE96ABC8E5AEDB3B8A1C966C196E543484E1378F62A8B5E48E9AE22229`，
  376 entries／375 檔案／1 個目錄佔位／反斜線 0／非 ASCII 0）
- **Claude 沒有重新打包美術 ZIP**，所以不可能重新引入反斜線路徑。
  你在 `v51-r003-codex` 做的跨平台路徑正規化成果完整保留。
- `v51_art_interface_spec.md` → `v52_art_interface_spec.md`：同樣位元不變承接。
  **v52 沒有新增任何需要美術素材的接口**（捕手六項是數值與文字，不需要新圖示或新槽位）。
- `v51_codex_to_claude_handoff.md` → `v52_codex_to_claude_handoff.md`：**位元不變承接**。
  這個方向的文件只有你能寫，Claude 不代寫、不改一個位元。你收到 v52 後可自行更新。

---

## 二、⚠ 本輪採「乙案：徹底修正」（Mars 2026-07-27 拍板）

這一段是 Mars 明確要求必須在交接摘要中註記的內容，請務必讀完。

v52 的兩個數值修正**不是表層調參，是徹底修正**。Mars 授權範圍與已知後果：

| 項目 | 內容 |
|---|---|
| 授權事項 | 允許改動打擊事件機率；接受回歸基線整批重建 |
| 引擎變更 | `simulateGame` 由「常態分布抽比分」改為「逐打席事件累積」（甲案：完全重寫） |
| 回歸基線 | v51 的 **1232 項 → v52 的 1299 項**（新增 67 項 v52 斷言，舊斷言隨新引擎重新校準） |
| 連帶重新校準 | 勝負分布、獎項門檻、AI 交易估值基準、牛棚出賽與局數分布 |
| 共用 RNG | **序列必然改變**，這是乙案的預期後果，不是缺陷 |

**對你的實際影響：**

1. **「回歸全綠＝共用 RNG 零變動」這個判準，在 v52 這一次升版不適用。**
   v51 以前 Claude 用它證明美術／統計改動沒污染模擬軌跡；v52 是比賽核心重寫，
   全綠證明的是新基線自洽。**v52 之後的版本恢復原紀律**，你的美術層仍然一律不得動共用 RNG。
2. **舊存檔可以繼續讀**：`ensureV52()` 惰性補值，不做破壞性遷移。
   舊捕手以既有三項專項的平均值補上新三項，不憑空變強。
3. **`sw.js` 快取鍵改為 `baseballgm-v52`**，PWA 會取得新資源。

---

## 三、v52 遊戲端變更摘要（與美術層無關，供你判斷影響面）

| 類別 | 內容 |
|---|---|
| 逐打席引擎 | 九種打席結果、壘包狀態機、換投調度、延長賽最多 6 局、勝敗投救援判定 |
| A5 捕手六項 | framing／gameCalling／caughtStealing ＋新增 blocking／popTime／pitcherHandling，六項全部接進引擎 |
| A1 W1~W5 | 全部補完（逐打席／wOBA 年度校準／非自責分掛鉤守備／估值動態縮放／進階數據進球探與選秀） |
| 兩數值 | 打擊率 .2385 → **.250**（命中靶心）；防禦率 6.270 → **3.86**（靶心 3.80） |
| 新統計欄位 | 打者 `R`／`PB`／`CSC`；投手 `OUTS`（`IP` 一律由 `OUTS` 換算） |
| 順帶修 bug | `processCoachContracts()` 對 AI 隊空缺直接跳過，導致永久缺人；已改為一律補實 |

**UI 層新增的顯示位置**（都用既有 CSS 變數與版面樣式，沒有新槽位需求）：
捕手六項出現在名單頁屬性列、完整資訊卡、球探報告、訓練室、特訓畫面、交易估值說明。
若你日後要為捕手專項做專屬圖示，那會是**新的槽位需求**，請先在 `codex_to_claude` handoff 提案，
由 Claude 更新 `art_interface_spec` 後再製作。

---

## 四、你的下一步（Codex 端未完成項，狀態未變）

| 項目 | 狀態 |
|------|------|
| 20 隊隊徽（512/128/64/32px） | ✅ 已完成 |
| 20 隊帽徽參考 capMarkReference | ✅ 已完成（輔助用，非正式圖層） |
| 20 隊品牌概念板 | ✅ 已完成 |
| 全 20 隊 capMark 完整帽子 | ✅ 已完成（T0–T4 已核准，T5–T19 **待 Mars 視覺核准**） |
| 全 20 隊 homeUniform | ✅ 已完成（同上核准狀態） |
| 全 20 隊 awayUniform | ✅ 已完成（同上核准狀態） |
| 通用肖像零件 skin/face/eyes/nose/hair/beard | ⬜ 待製作 |
| 語意圖示（97 個 emoji→SVG/PNG） | ⬜ 待製作 |
| 槽位資產（26 個） | ⬜ 待製作 |
| 國旗（40 國） | ⬜ 待製作 |
| 六大畫面背景／按鍵／卡片／雷達圖／事件素材 | ⬜ 待製作 |

**Mars 尚未核准 T5–T19，任何文件都不得寫成已核准。**
v52 的所有文件都遵守這一條，請你的文件也繼續遵守。

肖像零件的接口約定（`pack.portraits.layers` 結構、選層邏輯
`v49SeedHash(player.appearanceSeed, index) % layers[名].length`、index 對應與
beardChance 預設 30）在 `v52_art_interface_spec.md` 中原文保留，本輪未變更。
提醒仍然有效：**每層陣列長度可以不同，但擴充會改變既有球員外觀**（取餘數的除數變了），
若要外觀穩定應一次定案數量。

---

## 五、封裝規則與本輪 lineage

本輪為**正式升版**（v51 → v52），依 AGENTS.md 與 FUTURE_DELIVERY_STANDARD.md：

- 10 個外層角色全部換成 v52 檔名，`packageRevision` 從 1 起算，`formalVersionUpgrade: true`
- `basedOnPackageId` 與 `supersedesPackageId` 皆為 `v51-r003-codex`
- 母包 `v51_delivery.zip`（SHA-256
  `29BF46A56D226FFB5E960416D1EC896906FD72240794422B8C16A49FD683E669`，54,093,017 bytes）
  本身即歷史與回滾包，**不嵌入本包**，請自行保存
- **外層恰 10 個檔案，沒有第 11 份**
- `SHA256SUMS.txt` 最後重建，雜湊其餘 9 檔、**不雜湊自身**
- 未修改的角色記 `changeStatus: unchanged`，`carriedForwardFrom.contentSha256`
  等於母包同名檔案的 SHA-256（三個位元不變承接角色見第一節）

**同版往返時**（例如你要交回 `v52-r002-codex`）：`packageRevision` +1、
`basedOnPackageId` 指向 `v52-r001-claude`、`formalVersionUpgrade` 維持 false。
你在同一版次內交回的東西，Claude 一樣不會刪。

---

## 六、問題回報格式（沿用你的格式）

若 Claude 日後發現美術層問題，會照你的格式回報：根因／影響隊伍與檔案／
責任層（素材 vs Theme pack vs 渲染 vs 持久化）／向後相容策略／測試計畫。

**本輪沒有發現任何美術層問題**，也沒有對美術層提出任何新要求。

---

## 七、本輪驗收數據（Claude 實測，非轉述）

| 驗收項 | 結果 |
|---|---|
| `node test_regression.js` | **1299 通過 / 0 失敗**，exit 0 |
| `node smoke_multiyear.js` | 通過，exit 0 |
| `node smoke_puregm.js` | 通過，exit 0 |
| 整合單檔自驗 | **21 通過 / 0 失敗**（實測 BA .2493／ERA 3.873／每隊每場局數 9.00／非自責分 6.8%） |
| 模組 ZIP 檔數 | 恰 20 檔 |
| 外層角色數 | 恰 10 檔 |
| `SHA256SUMS.txt` | 9/9 通過，不含自身 |
| 美術 ZIP | 376 entries／375 檔案／1 目錄／反斜線 0／非 ASCII 0，與母包 SHA 相同 |

**尚未驗證**：v52 外層 ZIP 在 Windows PowerShell `Expand-Archive` 的實機解壓
（Claude 在 Linux 環境驗證）。美術 ZIP 為位元不變承接，你在 v51 輪的實機驗證結論繼續有效。
若你在 Windows 端解壓外層 ZIP 遇到任何問題，請寫進 `codex_to_claude` handoff。

---

## 新對話恢復（依 FUTURE_DELIVERY_STANDARD 第 3 節）

唯一權威脈絡還原摘要是 `v52_project_summary.md`，只有它含完整 copy-ready fenced block。
Codex 開新對話：上傳最新 `v52_delivery.zip` ＋ 貼上 `v52_project_summary.md` 的 fenced block。
本 handoff 只記交接與差異，不含還原摘要。

**若下一輪是封裝輪，記得同時附上母包 ZIP** —— 位元不變承接與 `carriedForwardFrom` 的 SHA
只能從母包實際算出，不能靠記憶或舊解壓目錄替代。
