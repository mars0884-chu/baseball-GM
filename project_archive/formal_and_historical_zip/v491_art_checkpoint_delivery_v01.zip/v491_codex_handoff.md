# 《決勝GM》v491 — Codex 美編交接摘要

> **本檔案專供 Codex 使用**，用於美術層開發對接。
> 完整程式脈絡見 `v491_project_summary.md`（Claude 工程用）。

---

## 一、專案概述

- **遊戲名稱**：決勝GM — FRONT OFFICE BASEBALL
- **類型**：瀏覽器端棒球GM經營模擬
- **目前版本**：v491
- **前端技術**：純 vanilla JavaScript（無框架），mobile-first
- **美術系統核心檔**：`00-theme.js`

---

## 二、v491 核心變動（與 v49 的差異）

### 變動 1：20隊名固定（TEAM_DEFS）
v49 的隊名是 `shuffle(CITY_NAMES) × shuffle(MASCOTS)` 每局隨機組合。
**v491 起隊名完全固定**，定義在 `01-data-engine.js` 的 `TEAM_DEFS`（Object.freeze）：

| teamId | 隊名 | 城市 | 暱稱 | 分區 |
|---|---|---|---|---|
| T0 | 靖安盾衛 | 靖安 | 盾衛 | A1（海風聯盟・第一分組） |
| T1 | 臨海獵鯊 | 臨海 | 獵鯊 | A1 |
| T2 | 曲江水牛 | 曲江 | 水牛 | A1 |
| T3 | 永昌雄獅 | 永昌 | 雄獅 | A1 |
| T4 | 明陽烈焰 | 明陽 | 烈焰 | A1 |
| T5 | 天啟鷹 | 天啟 | 鷹 | A2（海風聯盟・第二分組） |
| T6 | 龍城雲豹 | 龍城 | 雲豹 | A2 |
| T7 | 星野銀狐 | 星野 | 銀狐 | A2 |
| T8 | 雲夢白鷺 | 雲夢 | 白鷺 | A2 |
| T9 | 東寧豹 | 東寧 | 豹 | A2 |
| T10 | 嘉禾金穗 | 嘉禾 | 金穗 | B1（山岳聯盟・第一分組） |
| T11 | 瑞港海豚 | 瑞港 | 海豚 | B1 |
| T12 | 金川礦工 | 金川 | 礦工 | B1 |
| T13 | 玄武黑熊 | 玄武 | 黑熊 | B1 |
| T14 | 朝陽赤鷹 | 朝陽 | 赤鷹 | B1 |
| T15 | 鳳鳴紅雀 | 鳳鳴 | 紅雀 | B2（山岳聯盟・第二分組） |
| T16 | 銀灘破浪 | 銀灘 | 破浪 | B2 |
| T17 | 青川山羌 | 青川 | 山羌 | B2 |
| T18 | 望海白鯨 | 望海 | 白鯨 | B2 |
| T19 | 磐石鐵衛 | 磐石 | 鐵衛 | B2 |

**Codex 意義**：隊徽、帽徽、球衣、主輔色等美術資產可直接以 `teamId`（T0~T19）綁定，不再擔心隊名變動。

### 變動 2：聯盟品牌固定（LEAGUE_BRAND）
v49 聯盟名是隨機前綴（至高/寰宇/星辰…）。
**v491 起完全固定**，定義在 `01-data-engine.js` 的 `LEAGUE_BRAND`（Object.freeze）：

| 欄位 | 值 |
|---|---|
| fullName | 海嶺職業棒球聯盟 |
| shortName | 海嶺職棒 |
| englishName | HAILING PROFESSIONAL BASEBALL LEAGUE |
| englishShort | HPBL |
| leagueA | 海風聯盟 |
| leagueB | 山岳聯盟 |

**Codex 意義**：聯盟標誌、品牌色系、賽事視覺等均可安全綁定。

### 變動 3：開局流程簡化
- 玩家只輸入 **GM 姓名**（不再輸入球隊名稱、聯盟名稱）
- 一律進入**選隊畫面**，從20隊中選一隊
- `userTeamId` 指向玩家實際選中的隊伍，**不再強制 T0**

### 變動 4：國家系統確認
40 國（20真實+20虛構）的 `countryId` 在 v49 已固定，v491 未變動。Codex 可安全使用 `NAT_US`、`NAT_F01`~`NAT_F19`、`NAT_HOME` 等 ID 綁定國旗美術。

---

## 三、美術接口總覽（沿用 v49，v491 未新增接口）

### 3.1 品牌常數（00-theme.js → BRAND）
```javascript
BRAND.gameName       // "決勝GM"
BRAND.gameSubtitle   // "FRONT OFFICE BASEBALL"
BRAND.homeName       // "海嶺共和國"
BRAND.colors.primary // "#1769D2"（主藍）
BRAND.colors.white   // "#FFFFFF"（基底白）
BRAND.colors.green   // "#59C78B"（輔綠）
BRAND.colors.pink    // "#FF4F87"（輔粉）
BRAND.colors.dark    // "#102949"（墨藍）
```

### 3.2 語意圖示（00-theme.js → icon()）
- 97 個語意 key（如 `icon('trade')`、`icon('milestone')`）
- 預設回傳 emoji，主題包可覆寫為 `<img>` / SVG

### 3.3 CSS 美術槽位（00-theme.js → THEME_SLOTS，26 個）
透過 `applyThemePack(pack)` 注入 CSS 變數，涵蓋背景/按鍵/雷達圖/品牌色/卡片色/工具列。

### 3.4 隊徽 / 國旗
```javascript
themeTeamLogo(teamId, size)    // 預設回傳佔位方塊；主題包可覆寫為圖片
themeNationFlag(countryId, size) // 同上
```
- teamId：`T0`~`T19`（v491 固定對照表見第二節）
- countryId：`NAT_US`、`NAT_JP`、`NAT_F01`~`NAT_F19`、`NAT_HOME` 等

### 3.5 組合式肖像
```javascript
compositePortrait(playerId, optPlayer, size) // 預設回傳佔位圖
```
- 每位球員有 `appearanceSeed`（確定性雜湊，跨存讀不變）
- 圖層 z-order：skin→face→eyes→nose→mouth→uniform→hair→beard→cap

### 3.6 主題包結構（JSON）
```json
{
  "name": "主題包名稱",
  "version": "v491",
  "slots": { /* 26 個 CSS 變數鍵值 */ },
  "icons": { /* 97 個語意 key → 替換值 */ },
  "teamLogos": { "T0": "data:image/...", ... },
  "nationFlags": { "NAT_US": "data:image/...", ... },
  "portraits": { /* 零件庫 */ }
}
```
匯入：`applyThemePack(pack)` 或 `loadThemePackFromJSON(jsonStr)`
匯出/重設：主控台→主題設定頁

---

## 四、Codex 待辦清單（優先順序由 Mars 排定）

| 項目 | 狀態 | 備註 |
|---|---|---|
| 20 隊完整品牌（隊徽/帽徽/球衣/主輔色） | 🔴 未開始 | **v491 隊名已固定，可開工** |
| 聯盟品牌視覺（HPBL 標誌/賽事視覺） | 🔴 未開始 | **v491 聯盟名已固定，可開工** |
| 20 架空國旗 + 真實國旗正確版 | 🔴 未開始 | 含台灣中華民國國旗 |
| 組合式肖像零件 | 🔴 未開始 | 膚色/臉型/眉眼/鼻嘴/髮型/鬍型/帽子/球衣 |
| 97 個語意圖示正式版 | 🔴 未開始 | 取代預設 emoji |
| 六大畫面背景 | 🔴 未開始 | 主控台/財務/名單/選秀/交易/設施 |
| 按鍵、卡片、雷達圖、事件資產 | 🔴 未開始 | |
| 正式主題包 JSON 封裝 | 🔴 未開始 | 依 3.6 結構 |

---

## 五、鐵則提醒

1. **美術不動遊戲規則**：美術層修改不得改變遊戲規則、數值、機率、模擬、存檔語意
2. **接口不足時**：提出缺口清單交 Claude/Mars，不自行改遊戲程式碼
3. **全繁體中文**：所有 UI 文字、圖示 alt text 均使用繁體中文
4. **檔名純 ASCII**：交付檔案名稱嚴格 ASCII

---

## 六、Codex 本輪美術進度（2026-07-25）

- 20/20 隊兩套球衣品牌概念板已完成。
- 球衣固定為白色系主場＋球隊主色系客場；灰色與第三套城市版取消。
- 已輸出 20 隊透明主隊徽 512／128／64／32px。
- 已輸出 20 張 `capMarkReference`，部分為獨立帽徽，部分為完整帽型參考。
- 共 100 張 PNG，機器驗證全部通過。
- 本輪未修改遊戲規則、數值、模擬、RNG 或存檔。

## 七、請 Claude 先確認的接口

1. `capMark` 是完整帽子層，或拆成 `capBase`＋`capInsignia`。
2. 固定肖像母版尺寸、頭頂、臉心、帽沿與領口錨點。
3. 固定正式 z-order；目前程式實際順序須以 `00-theme.js` 為準。
4. 確認遊戲依主客場切換 `homeUniform`／`awayUniform`。
5. `cityUniform` 留空時回退到 `awayUniform`，或明確省略。

在以上項目確認前：

- 可以接入 `logo`、`primaryColor`、`secondaryColor`。
- 不要把 `capMarkReference` 直接誤填為正式 `capMark`。
- `capMark`、`homeUniform`、`awayUniform`、`cityUniform` 暫時保持空值。

## 八、本次外層交付

- `491_baseball_gm.html`
- `491_baseball_gm_modular.zip`
- `v491_project_summary.md`
- `v491_claude_handoff.md`
- `v491_art_assets.zip`
- `SHA256SUMS.txt`

`v491_art_assets.zip` 內含：

- 20 隊共 100 張透明 PNG。
- 固定 `teamId` 映射清單。
- 自動驗證報告。
- 全聯盟透明素材 QA 圖。
- 接口缺口與正式品牌素材階段文件。
- 可重建抽取與 QA 工具。

*本交接摘要更新於 v491 美術檢查點 v01（2026-07-25）。*
