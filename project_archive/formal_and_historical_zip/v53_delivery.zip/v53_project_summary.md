---
documentRole: project-summary
gameVersion: v53
documentRevision: 4
originalAuthor: Claude
lastModifiedBy: Codex
authoritative: true
packageId: v53-r003-codex
---

# 決勝GM v53 唯一權威專案摘要

更新：2026-08-01

本文件是 v53-r003 唯一完整脈絡還原摘要；其他 handoff 只負責單向交辦。

## 最新完整交付

- 檔案：`v53_delivery.zip`
- packageId：`v53-r003-codex`
- basedOn／supersedes：`v53-r002-codex`
- 母包 SHA-256：`B76AE5F124482EC73072C071A05B3E7BEE5C9CD81447D263F766B00D11156F48`
- formalVersionUpgrade：`false`
- 固定外層角色：10；SHA entries：9；模組 ZIP：20 檔。

## Mars 最新拍板

- 球員名單使用純頭像，不再組合目前的小身體。
- 大頭方向保留；問題是現有頭與身體不是同一套線條、立體感與肩寬，不是單純圖片尺寸。
- 名單、選秀、自由市場、國際市場、交易、場上 token 使用 `rosterHeadOnlyCentered`。
- 移除身體後，整個頭像群組在 256px 下移 6px；128／64px 從置中的完整 256px 圖層重建。帽頂不再貼齊，底部裁切像素 0。
- 詳細頁在新整體肩膀／衣領完成前同樣使用純頭像 fallback。
- 現有小身體標記為 `rejected-do-not-use`，不得縮放、修補或重新接回。

## 已完成內容與來源區分

### Claude 原始內容（Codex 位元不變承接）

- v53 階段 1 主題載入與渲染出口。
- `53_baseball_gm.html`、20 檔模組 ZIP、art interface spec、Claude→Codex handoff。
- Codex 未修改程式、RNG、存檔語意或 Claude 擁有文件。

### Codex v53-r002 已完成

- 已確認 batch10 頭型、膚色、表情與帽位。
- 5 款鬍型（含無鬍）×6 色的 style/color 分離結構。
- 72 個正式鬍型檔；120/120 Alpha 與幾何對位一致。
- 移除所有舊 `portraits/common` 頭像引用。

### Codex v53-r003 新增或修改

- 新主題：`theme_pack/v53_official_brand_theme_paths_v07_roster_head_only.json`。
- 預設 layerOrder 改為 `skin → beard → face → hair → cap`，完全排除 uniform/body。
- 新增 `displayModeConfig`，定義 rosterHeadOnlyCentered contexts、64／96／128px 建議尺寸與 detail fallback。
- 222 個 head-only 正式圖層無裁切下移；各層相對幾何不變。
- 明確禁止現有小身體作為任何 fallback。
- 正式美術 ZIP 仍維持 runtime-only：382 production assets＋1 theme＋2 docs。

### Codex 驗證確認

- 主題 direct refs 202、missing 0、`portraits/common` refs 0。
- 預設 layerOrder 與 rosterHeadOnly 均不含 uniform/body。
- 美術 ZIP 385 檔；反斜線 0、unsafe 0、重複 0、1254／512／32px 0。
- 外層 10、SHA 9/9、模組 20。
- regression 1315/0、一般 15 年 smoke、純 GM 15 年 smoke 均通過。

## 未完成與不得推論

- 詳細頁 bust 尚未製作；須另做與頭部同一視覺系統的肩膀／衣領並由 Mars 確認。
- 9 款非光頭核准 1254px 透明母層仍不在權威來源鏈；不得從確認表、縮圖、退件候選或整張生成圖重建。
- Claude 尚未完成 head-only contexts 與 v53 階段 2 程式接線。

## 下一步與角色分工

### Claude

1. 尊重主題 head-only 預設，不在其後硬貼 uniform/body。
2. 對指定 contexts 使用 `rosterHeadOnlyCentered`；詳細頁暫時 fallback。
3. 完成 beard style/color、combined expression、舊存檔與 RNG 相容接線。
4. 接線後重跑完整測試。

### Codex

- 只做美術；下一個人物工作是詳細頁用整體肩膀／衣領樣式，必須先交 Mars 單款確認。
- 收到合法 1254px 髮型母層後，一次製作一款。

### Mars

- 將最新 `v53_delivery.zip` 交給 Claude 接線。
- 詳細頁 bust 候選完成時拍板。
- 確認已存檔後才授權淘汰舊包。

## 新對話脈絡還原（唯一可複製區塊）

```markdown
專案：決勝GM v53
最新完整包：v53_delivery.zip
packageId：v53-r003-codex
母包：v53-r002-codex
Mars最新拍板：球員名單改用純頭像；保留大頭方向；現有小身體 rejected-do-not-use。
新主題：v53_official_brand_theme_paths_v07_roster_head_only.json
預設疊層：skin → beard → face → hair → cap；不含 uniform/body。
置中：整個頭像群組 256px +6；128/64px 從完整置中的 256px 圖層重建；帽頂保留安全空間、底部裁切0、相對幾何不變。
適用：roster、draft、freeAgents、internationalMarket、tradeBuilder、lineupTokens；詳細頁暫用相同 fallback。
已確認：頭型、膚色、5表情、帽位、5鬍型含無鬍×6色；120/120 Alpha與幾何一致。
美術包：385檔，production 382，theme 1，docs 2；反斜線0，1254/512/32px 0。
程式測試：regression 1315/0；一般15年與純GM 15年 smoke 通過。
Claude下一步：接 head-only contexts、beard style/color、combined expression，保留舊存檔與 RNG，不得接回小身體或 portraits/common。
Codex下一步：詳細頁整體肩膀/衣領美術；9款非光頭等待合法1254透明母層。
```
