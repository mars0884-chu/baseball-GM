---
documentRole: codex-to-claude-handoff
gameVersion: v53
documentRevision: 10
originalAuthor: Codex
lastModifiedBy: Codex
authoritative: false
packageId: v53-r003-codex
---

# v53-r003 Codex → Claude handoff

## Lineage 與權限邊界

- packageId：`v53-r003-codex`
- basedOn／supersedes：`v53-r002-codex`
- 母包 SHA-256：`B76AE5F124482EC73072C071A05B3E7BEE5C9CD81447D263F766B00D11156F48`
- Codex 僅修改美術 ZIP、共用摘要、待辦、自己的 handoff、manifest 與 SHA。
- `53_baseball_gm.html`、`53_baseball_gm_modular.zip`、`v53_art_interface_spec.md`、`v53_claude_to_codex_handoff.md` 均與母包位元相同。

## Mars 最新拍板：球員名單使用純頭像

- 日期：2026-08-01。
- 大頭方向保留；撤回「大頭＋現有小身體」的名單組合。
- 問題不是圖片太小，而是頭部與小身體的線條、立體感、肩寬及接縫不是同一套視覺系統；縮小後只會更明顯。
- 名單、選秀、自由市場、國際市場、交易與場上 token 使用 `rosterHeadOnly`。
- 球隊辨識由帽子與帽徽負責，不需要在小尺寸重複顯示球衣。
- 球員詳細頁在新肩膀／衣領美術完成前，同樣 fallback 到純頭像；禁止沿用或縮放目前的小身體。

## 新主題合約

- 主題：`theme_pack/v53_official_brand_theme_paths_v07_roster_head_only.json`
- 全域安全預設 `rendererConfig.layerOrder`：`skin → beard → face → hair → cap`。
- `rendererConfig.defaultDisplayMode`：`rosterHeadOnlyCentered`。
- `portraits.displayModeConfig.modes.rosterHeadOnlyCentered`：
  - `includesUniformOrBody: false`
  - 建議顯示尺寸：64／96／128px
  - contexts：roster、draft、freeAgents、internationalMarket、tradeBuilder、lineupTokens
- 整個頭像群組已直接套入正式素材：256px y+6；128／64px 由完整置中的 256px 圖層用 LANCZOS 重建。帽頂留白恢復、裁切像素 0、所有層相對幾何不變。
- `playerDetailBust`：狀態為 `pending-new-unified-shoulder-collar-art`，fallback 為 `rosterHeadOnly`，並禁止 `existing-tiny-uniform-body-composite`。

## Claude 必須完成

1. 載入主題時尊重全域 head-only layerOrder；不得在合成後額外硬貼 uniform/body。
2. 若要區分不同畫面，讀取 `displayModeConfig`，上述名單 contexts 固定使用 `rosterHeadOnly`。
3. 詳細頁在新 bust 美術交付前使用 head-only fallback。
4. 繼續完成 v53 階段 2：beard style/color 獨立索引、combined expression、舊存檔與 RNG 相容。
5. 不得重新引用 `production_assets/portraits/common/` 或舊小身體作為 fallback。
6. 接線後重跑 regression、兩套 15 年 smoke、theme preload、舊存檔 round-trip 與 RNG 相容測試。

## 沿用且未重開的已確認內容

- batch10 頭型、膚色、表情幾何與帽位。
- 5 款鬍型（含無鬍）×6 色的 style/color 分離結構。
- 4 款可見鬍型×6 色×64／128／256px＝72 個正式檔。
- 120/120 組鬍型×顏色×表情 Alpha 與幾何一致。
- 9 款非光頭仍等待核准 1254px 透明母層；不得從確認表、縮圖或退件圖重建。

## 美術交付與驗證

- `v53_art_assets.zip`：385 檔＝382 production assets＋1 theme pack＋2 docs。
- 美術 ZIP SHA-256：`C36D8E9DB641049E52F47274E08DE18D5EC91DC128A7AA4E4FEE64DC7271FEF7`
- direct theme refs：202；missing 0；舊 `portraits/common` refs 0。
- 預設 layerOrder 不含 uniform/body；`rosterHeadOnlyCentered.includesUniformOrBody=false`。
- 222 個 head-only 正式圖層已無裁切下移置中；256px y+6，128／64px 從置中 256px 重建。
- 反斜線 0、unsafe 0、重複 0、1254／512／32px 0。
- 過程比較圖不在正式美術 ZIP；由 Codex 工作區保留。
