---
documentRole: claude-to-codex-handoff
gameVersion: v53
documentRevision: 1
originalAuthor: Claude
lastModifiedBy: Claude
authoritative: true
packageId: v53-r001-claude
---

# Claude → Codex 交接（v53 美術渲染出口＋結構驗證閘門）

> v53 階段 1 已由 Claude 完成程式面：12 處渲染出口開啟、applyThemePack 結構驗證閘門補上。
> 以下三件事需要 Codex 在下一包處理。

---

## 1. 美術 ZIP 路徑正規化為正斜線

**問題**：v52-r001-claude 交付的美術 ZIP 內部路徑有 0 條反斜線（全為正斜線）。
v52-r005-codex 交付的美術 ZIP 退步到 **2935 條反斜線**路徑。

```
# v52-r005-codex 中的反斜線範例：
production_assets\128\teams\T0\logo_128.png     ← 應為 production_assets/128/teams/T0/logo_128.png
```

**要求**：下一包起，美術 ZIP 內所有路徑一律使用 **正斜線**（`/`），不得包含反斜線（`\`）。
這是跨平台相容性的基本要求——macOS/Linux/iOS 解壓反斜線路徑時會出現異常。

**驗收方式**：`unzip -l <art_zip> | grep '\\' | wc -l` 必須為 0。

---

## 2. 鬍型六色主題包退回 Codex 產出

**背景**：00-theme.js 的分工定義為「Codex 產出主題包」。鬍型的款式索引與顏色索引分離架構
（v53 階段 2 規劃）應由 Codex 在主題包中實作。

**目前狀態**：
- 現有鬍型圖層在 `portraits.layers.beard` 陣列中，每個索引是一個完整的鬍型圖片
- v53 階段 2 設計：將款式（形狀）與顏色（六色）分離，允許同一款式搭配不同顏色
- 這需要主題包結構擴充（在 `portraits` 區段增加 beard 的款式×顏色矩陣或分離索引）

**Codex 需做的事**：
1. 設計 beard 款式×顏色的主題包結構（建議方案：`portraits.layers.beard` 改為二維陣列
   或新增 `portraits.beardConfig` 物件）
2. 產出對應的圖層素材（每款式×六色＝圖片數）
3. 在下一包的 codex_to_claude_handoff 中回報採用的結構，Claude 再接線程式面

---

## 3. 美術交付範圍限縮（Mars 已批准）

**新規則**：下一包起，美術 ZIP 只需包含以下內容：

### 保留（遊戲需要）
- `production_assets/` 的 **64px、128px、256px、svg** 子目錄
- `theme_pack/` 最新版主題包 JSON
- `docs/` 的 manifest 與 validation 文件

### 不再附（過程證據，開發者本機保留即可）
- ❌ `source_assets/`（母檔）
- ❌ `concept_boards/`（概念草稿）
- ❌ `previews/`（聯絡表/測試圖）
- ❌ `checkpoint/`（中間檢查點）
- ❌ `source_templates/`（範本原稿）
- ❌ `tools/`（建置腳本）
- ❌ `production_assets/1254/`（1254px 母檔——永不內嵌遊戲）
- ❌ `production_assets/512/`（512px 中間尺寸——非遊戲用）
- ❌ `production_assets/32/`（32px 太小，遊戲不使用）

**體積估算**（依 v52-r005-codex 實測）：
- 限縮前：約 197MB（含過程證據約 190MB）
- 限縮後：約 **18MB**（64px 1.77MB + 128px 4.67MB + 256px 11.73MB + svg 0.16MB + theme_pack + docs）

### 體積規則（供 Codex 建主題包參考）

- **模組版**：使用路徑式主題包＋assets 資料夾，可到 256px
- **單檔版 HTML**：用 base64 內嵌，只放 64/128px，總計上限 3MB
- **1254px 母檔**：永不內嵌遊戲

---

## 程式面變更摘要（供 Codex 了解）

### 新增函式
- `v53IsThemePack(obj)` — 結構驗證閘門，拒絕 manifest 類物件
- `v53NationFlagByName(nationality, size)` — 由國籍名稱（如「美國」）查 countryId 再取國旗

### 修改函式
- `applyThemePack(pack)` — 加入 v53 結構驗證閘門，拒絕後設定 `THEME.lastLoadError`
- `loadThemePackFromJSON(text)` — 回傳閘門錯誤訊息而非「格式不符」

### 新增渲染出口（12 處）
見 v53_project_summary.md 的渲染出口表格。全部 graceful fallback，
無主題包時與 v52 位元等價。

### 回歸測試
1299 → **1315**（+16 v53 新測試），雙 smoke 全過。
