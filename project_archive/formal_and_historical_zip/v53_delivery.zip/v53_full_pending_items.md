---
documentRole: full-pending-items
gameVersion: v53
documentRevision: 4
originalAuthor: Claude
lastModifiedBy: Codex
authoritative: false
packageId: v53-r003-codex
---

# 決勝GM v53 完整待辦事項

## v53 美術階段

| 項目 | 狀態 |
|------|------|
| 階段 1：渲染出口與結構驗證 | ✅ Claude 完成 |
| 階段 2：鬍型款式×顏色分離美術 | ✅ Codex 完成；Claude 接線待辦 |
| 球員名單純頭像方向 | ✅ Mars 拍板；Codex 主題合約完成；Claude contexts 接線待辦 |
| 詳細頁整體肩膀／衣領 | 待 Codex 另做美術；目前使用純頭像 fallback |
| 階段 3：主題包內建化 | 待階段 2 接線完成 |

## v53-r003 待 Claude 接線

- 尊重主題預設 `skin → beard → face → hair → cap`；不得附加 uniform/body。
- roster、draft、freeAgents、internationalMarket、tradeBuilder、lineupTokens 使用 `rosterHeadOnlyCentered`。
- playerDetail、largePlayerCard 在新 bust 美術完成前使用 `rosterHeadOnlyCentered` fallback。
- 接線 beard style/color、combined expression，保留舊存檔與 RNG 序列。
- 不得把舊 `portraits/common` 或現有小身體接回去。
- 接線後執行 theme preload、舊存檔 round-trip、RNG 相容、regression 與兩套 15 年 smoke。

## 待 Codex 美術

- 詳細頁用的整體肩膀／衣領：必須與已確認頭部使用相同線條、立體感及肩寬，不能縮放或修補目前的小身體。
- 9 款非光頭：等待各款核准 1254px 透明母層後一次製作一款。

## 尚未開始的遊戲大項

| 編號 | 項目 | 建議順序 |
|------|------|----------|
| A2 | 農場多層級（一軍／二軍 → 三層以上） | 下一個做 |
| A4 | 承諾系統（簽約承諾與兌現追蹤） | A2 之後 |
| A3 | 球隊文化／城市記憶／二代傳承 | 最後做 |

## 五類缺口

- 程式缺陷：未發現新增缺陷；head-only contexts 與階段 2 接線尚未完成。
- 測試缺口：上述接線後才可驗證 theme preload、舊存檔與 RNG 相容。
- 文件缺口：無。
- 封裝缺口：無。
- 未完成專案工作：詳細頁 bust、9 款髮型母層、階段 2 接線、階段 3、A2、A4、A3。
